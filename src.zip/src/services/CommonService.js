import http from '../config/http-main';

class CommonService {
  saveLookupMaster(data) {
    return http.post("api/lookups", data);
  }
  updateLookupMaster(id, data) {
    return http.post(`api/lookups/Main/${id}`, data);
  }
  getLookupMasterById(id) {
    return http.get(`api/lookups/${id}`);
  }
  getAllLookupMaster() {
    return http.get("api/lookups");
  }
  deleteLookupMasterById(id) {
    return http.delete(`api/lookups/${id}`);
  }
  saveLookupDetail(data) {
    return http.post("api/lud", data);
  }
  updateLookupDetail(id, data) {
    return http.post(`api/lud/Main/${id}`, data);
  }
  getLookupDetailById(id) {
    return http.get(`api/lud/${id}`);
  }
  getLookupDetailByLookupId(id) {
    return http.get(`api/lud/lookupId/${id}`);
  }
  getAllLookupDetail() {
    return http.get("api/lud");
  }
  deleteLookupDetailById(id) {
    return http.delete(`api/lud/${id}`);
  }
  /*saveGaiConfig(data) {
    return http.post("/gaiConfig", data);
  }
  updateGaiConfig(id, data) {
    return http.put(`/gaiConfig/${id}`, data);
  }
  getGaiConfigById(id) {
    return http.get(`gaiConfig/${id}`);
  }
  getAllGaiConfig() {
    return http.get("gaiConfig");
  }
  deleteGaiConfigById(id) {
    return http.delete(`/gaiConfig/${id}`);
  }
  getGaiEmployees() {
    return http.get("gaiIpromis");
  }
  getGaiEmployeeById(id) {
    return http.get(`gaiIpromis/${id}`);
  }
  getGaiEmpDependantsAll() {
    return http.get("gaiDependant");
  }
  getGaiEmpDependants(id) {
    return http.get(`gaiDependant/${id}`);
  }*/
  
}

export default new CommonService();