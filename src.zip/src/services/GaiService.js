import http from '../config/http-main';

class GaiService {
  saveGai(data) {
    return http.post("/gai", data);
  }
  updateGai(id, data) {
    return http.put(`/gai/${id}`, data);
  }
  getGaiById(id) {
    return http.get(`gai/${id}`);
  }
  getGaiByEmpId(id) {
    return http.get(`gai/gaiemp/${id}`);
  }
  getAllGai() {
    return http.get("gai");
  }
  deleteGaiById(id) {
    return http.delete(`/gai/${id}`);
  }
  saveGaiConfig(data) {
    return http.post("/gaiConfig", data);
  }
  updateGaiConfig(id, data) {
    return http.put(`/gaiConfig/${id}`, data);
  }
  getGaiConfigById(id) {
    return http.get(`gaiConfig/${id}`);
  }
  getAllGaiConfig() {
    return http.get("gaiConfig");
  }
  deleteGaiConfigById(id) {
    return http.delete(`/gaiConfig/${id}`);
  }
  getGaiEmployees() {
    return http.get("gaiIpromis");
  }
  getGaiEmployeeById(id) {
    return http.get(`gai/gaiIpromis/${id}`);
  }
  getGaiEmpDependantsAll() {
    return http.get("gai/gaiDependant");
  }
  getGaiEmpDependants(id) {
    return http.get(`gai/gaiDependant/${id}`);
  }
  getMedClaimInsuranceConfigDetailBasedOnFinYear(year) {
    return http.get(`api/policy-config-details/year/${year}`);    
  }
  getMedClaimInsuranceConfigMasterBasedOnFinYear(year) {
    return http.get(`api/policy-config-masters/year/${year}`);    
  }
  saveMedClaimInsuranceConfigMaster(data) {
    return http.post("api/policy-config-masters",data);    
  }
  updatePolicyConfigMaster(id, data) {
    return http.put(`api/policy-config-masters/${id}`, data);
  }
  deleteMedClaimInsuranceConfigMaster(id) {
    return http.delete(`api/policy-config-masters/${id}`);
  }
  createPolicyConfigDetail(data) {
    return http.post("api/policy-config-details",data);    
  }
  updatePolicyConfigDetail(id, data) {
    return http.put(`api/policy-config-details/${id}`, data);
  }
  deletePolicyConfigDetail(id) {
    return http.delete(`api/policy-config-details/${id}`);
  }
  getSumInsuredDataByYear(year) {
    return http.get(`api/policy-config-details/sum-insured/${year}`);
  }

  saveMedClaimInsurance(data) {
    return http.post("/api/policies",data);    
  }
  getMedClaimInsuranceByFinYearEmpCode(year,empCode){
    return http.get(`/api/policies/${year}/${empCode}`);   
  }
  updateMedClaimInsurance(id, data) {
    return http.put(`/api/policies/${id}`, data);
  }
  /*getMedClaimInsuranceByFinYearEmpCode(){

  }
  updateMedClaimInsurance(id, data) {
    return http.put(`/api/policies/${id}`, data);
  }
  deleteMedClaimInsurance(id) {
    return http.delete(`/api/policies/${id}`);
  }*/

  deleteMedClaimInsuranceDetailById(id) {
    return http.delete(`/api/policy-details/medclaim/${id}`);
  }
}

export default new GaiService();