import axios from "axios";
export default axios.create({
  //baseURL:  "http://10.176.16.244:8092/gai/",
  baseURL:  "http://172.16.18.134:8090/misgai/",  
  mode:"cors",
  headers: {
    "Content-type": "application/json",
    "Access-Control-Allow-Origin" : "*",
    'Access-Control-Allow-Methods': "*",
    "Access-Control-Allow-Headers": "*"
   }
});