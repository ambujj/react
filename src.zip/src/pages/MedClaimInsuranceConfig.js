import React, { useState, useEffect } from 'react';
import '../css/form.css';
import '../css/gai.css';
import MciService from '../services/GaiService';
import CommonService from '../services/CommonService';

const MedClaimInsurance = () => {
  const [finYearOptions, setFinYearOptions] = useState([]);
  const [selectedFinYear, setSelectedFinYear] = useState('');
  const [policyName, setPolicyName] = useState('');
  const [policyDescription, setPolicyDescription] = useState('');
  const [remarks, setRemarks] = useState('');
  const [status, setStatus] = useState('ACTIVE');
  const [masterId, setMasterId] = useState('');
  const [policyConfigDetails, setPolicyConfigDetails] = useState([]);
  const [policyConfigMaster, setPolicyConfigMaster] = useState([]);
  const [lookUpDetailsMemCategory, setLookUpDetailsMemCategory] = useState([]);
  const [sumInsured, setSumInsured] = useState('');
  const [memberCategory, setMemberCategory] = useState('');
  const [premiumToPay, setPremiumToPay] = useState('');
  const [detailRemarks, setDetailRemarks] = useState('');
  const [detailStatus, setDetailStatus] = useState('ACTIVE');
  const [editingMasterId, setEditingMasterId] = useState(null);
  const [editingDetailId, setEditingDetailId] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    fetchFinYearOptions();
    fetchMemberCategoryLookUp();
  }, []);

  const fetchMemberCategoryLookUp = async () => {
    try {
      const response = await CommonService.getLookupDetailByLookupId(3);
      setLookUpDetailsMemCategory(response.data);
    } catch (error) {
      console.error('Error fetching Member Category Data:', error);
    }
  };

  const fetchFinYearOptions = async () => {
    try {
      const currentYear = new Date().getFullYear();
      const finYears = [];
      for (let year = currentYear + 1; year >= 2023; year--) {
        finYears.push(`${year - 1}-${year}`);
      }
      setFinYearOptions(finYears);
    } catch (error) {
      console.error('Error fetching fin year options:', error);
    }
  };

  const handleFinYearChange = (event) => {
    setSelectedFinYear(event.target.value);
    fetchPolicyConfigDetails(event.target.value);
    fetchPolicyConfigMaster(event.target.value);
  };

  const fetchPolicyConfigDetails = async (finYear) => {
    try {
      const response = await MciService.getMedClaimInsuranceConfigDetailBasedOnFinYear(finYear);
      console.log(response.data);
      setPolicyConfigDetails(response.data);
    } catch (error) {
      console.error('Error fetching policy config details:', error);
    }
  };

  const fetchPolicyConfigMaster= async (finYear) => {
    try {
      console.log(finYear);
      const response = await MciService.getMedClaimInsuranceConfigMasterBasedOnFinYear(finYear);
      setPolicyConfigMaster(response.data);
      console.log(response.data);
    } catch (error) {
      console.error('Error fetching policy config details:', error);
    }
  };

/*
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await CommonService.saveLookupDetail(lookupDetail);
      console.log(response.data.message);
      resetForm();
      fetchLookupDetails();
      setSuccessMessage('Successfully Saved Data');
    } catch (error) {
      console.error('Error saving lookup detail:', error);
    }
  };
*/
const handleSubmitMaster = async (event) => {
  event.preventDefault();
  try {
    console.log("Master");
    if (editingMasterId) {
      // Editing an existing master record
      const updatedPolicyConfigMaster = policyConfigMaster.map((detail) => {
        if (detail.id === editingMasterId) {
          console.log("Master Edit");
          return {
            ...detail,
            policyName,
            policyDescription,
            remarks,
            status,
          };
        }
        return detail;
      });
      setPolicyConfigMaster(updatedPolicyConfigMaster);
      const response = await MciService.updateMedClaimInsuranceConfigMaster(editingMasterId, {
        selectedFinYear,
        policyName,
        policyDescription,
        remarks,
        status,
      });
      console.log(response.data.message);
      resetMasterForm();
      setSuccessMessage('Successfully Updated Data');
      setEditingMasterId(null);
    } else {
      
      // Creating a new master record
      const newMaster = {
        finYear:selectedFinYear,
        policyName,
        policyDescription,
        remarks,
        status,
      };
      console.log("Master Save  "+JSON.stringify(newMaster));
      setPolicyConfigMaster([...policyConfigMaster, newMaster]);
      const response = await MciService.saveMedClaimInsuranceConfigMaster(newMaster);
      console.log(response.data);
      resetMasterForm();
      setSuccessMessage('Successfully Saved Data');
    }
  } catch (error) {
    if (error.response && error.response.status === 500 && error.response.data === 'could not execute statement; SQL [n/a]; constraint [PIS.FIN_YEAR_POLICY_NAME]') {
       alert('Duplicate Entry ');
      console.log('Duplicate Entry Found ');
    } else {
      console.error('Error fetching policy details:', error);
    }
  }
};


  const handleEditMaster = (master) => {
    setEditingMasterId(master.id);
    setPolicyName(master.policyName);
    setPolicyDescription(master.policyDescription);
    setRemarks(master.remarks);
    setStatus(master.status);
  };

  const handleDeleteMaster = (master) => {
    if (window.confirm('Are you sure you want to delete this master record?')) {
      const updatedPolicyConfigMaster = policyConfigMaster.filter((detail) => detail.id !== master.id);
      setPolicyConfigMaster(updatedPolicyConfigMaster);
      resetMasterForm();
    }
  };

  const resetMasterForm = () => {
    setPolicyName('');
    setPolicyDescription('');
    setRemarks('');
    setStatus('ACTIVE');
    setEditingMasterId(null);
  };

  const handleSubmitDetail = async (event) => {
    event.preventDefault();
    if (editingDetailId) {
      // Editing an existing detail record
      console.log(JSON.stringify(lookUpDetails))
      const updatedPolicyConfigDetails = policyConfigDetails.map((detail) => {
        if (detail.id === editingDetailId) {
         // console.log(editingDetailId+"-----"+memberCategory)
          const MemCategory = lookUpDetails.find(
            (category) => category.displayName === memberCategory
          );
          //console.log(MemCategory);
          return {            
            ...detail,
            sumInsured,
            memberCategory: {
              id: MemCategory.id,
              lookupId: MemCategory.lookupId,
              detailCode: MemCategory.detailCode,
              displayName: MemCategory.displayName,
              description: MemCategory.description,
              status: MemCategory.status,
              parentCode: MemCategory.parentCode,
              orderingColumn: MemCategory.orderingColumn
            },
            premiumToPay,
            remarks: detailRemarks,
            status: detailStatus,
          };
        }        
        return detail;
      });

      setPolicyConfigDetails(updatedPolicyConfigDetails);

      const updatedPolicyConfigDetail = {
        ...updatedPolicyConfigDetails.find((detail) => detail.id === editingDetailId)
      };
      console.log(updatedPolicyConfigDetail);
      const response = await MciService.updatePolicyConfigDetail(editingDetailId, updatedPolicyConfigDetail);
      console.log(response.data)
      resetDetailForm();
      setSuccessMessage('Successfully Updated Detail Data');
      setEditingMasterId(null);

    } else {
      // Creating a new detail record
      const newDetail = {
        id: Date.now(),
        masterId,
        sumInsured,
        memberCategory,
        premiumToPay,
        remarks: detailRemarks,
        status: detailStatus,
      };
      setPolicyConfigDetails([...policyConfigDetails, newDetail]);
    }
    resetDetailForm();
  };

  const handleEditDetail = (detail) => {
    setEditingDetailId(detail.id);
    setMasterId(detail.master.policyName);
    setSumInsured(detail.sumInsured);
    setMemberCategory(detail.memberCategory.displayName);
    setPremiumToPay(detail.premiumToPay);
    setDetailRemarks(detail.remarks);
    setDetailStatus(detail.status);
  };

 
  const handleDeleteDetail = async (detailId) => {
    if (window.confirm('Are you sure you want to delete this detail record?')) {
      try {
        const updatedPolicyConfigDetails = policyConfigDetails.filter((detail) => detail.id !== detailId);
        const response=await MciService.deletePolicyConfigDetail(detailId);
        console.log(response.data);
        setPolicyConfigDetails(updatedPolicyConfigDetails);
        setSuccessMessage('Policy config detail deleted successfully');        
      } catch (error) {
        console.error('Error deleting policy config detail:', error);
      }
    }   
  };

  const resetDetailForm = () => {
    setMasterId('');
    setSumInsured('');
    setMemberCategory('');
    setPremiumToPay('');
    setDetailRemarks('');
    setDetailStatus('ACTIVE');
    setEditingDetailId(null);
  };

  return (
    <div>
      <h1>Policy Configuration</h1>

      <form onSubmit={handleSubmitMaster}>
        <div>
          <label htmlFor="finYear">Financial Year:</label>
          <select id="finYear" value={selectedFinYear} onChange={handleFinYearChange}>
            <option value="">Select Fin Year</option>
            {finYearOptions.map((finYear) => (
              <option key={finYear} value={finYear}>
                {finYear}
              </option>
            ))}
          </select>
        </div>

        <h2>Policy Details</h2>

      <table>
        <thead>
          <tr>
            <th>Policy Name</th>
            <th>Policy Description</th>
            <th>Notes</th>
            <th>Status</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {policyConfigMaster && policyConfigMaster.length ? (
            policyConfigMaster.map((master) => (
              <tr key={master.id}>
                <td>{master.policyName}</td>
                <td>{master.policyDescription}</td>
                <td>{master.remarks}</td>
                <td>{master.status}</td>
                <td>
                  <button>Edit</button>
                </td>
                <td>
                  <button>Delete</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7">No data available</td>
            </tr>
          )}
        </tbody>
      </table>

        <div>
          <label htmlFor="policyName">Policy Name:</label>
          <input type="text" id="policyName" value={policyName} onChange={(e) => setPolicyName(e.target.value)} />
        </div>

        <div>
          <label htmlFor="policyDescription">Policy Description:</label>
          <input
            type="text"
            id="policyDescription"
            value={policyDescription}
            onChange={(e) => setPolicyDescription(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="remarks">Remarks:</label>
          <input type="text" id="remarks" value={remarks} onChange={(e) => setRemarks(e.target.value)} />
        </div>

        <div>
          <label htmlFor="status">Status:</label>
          <select id="status" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="ACTIVE">ACTIVE</option>
            <option value="INACTIVE">INACTIVE</option>
          </select>
        </div>

        <button type="submit">{editingMasterId ? 'Update' : 'Save'}</button>
      </form>

      <h2>Policy Config Details</h2>

      <table>
        <thead>
          <tr>
            <th>Policy</th>
            <th>Sum Insured</th>
            <th>Member Category</th>
            <th>Premium to Pay</th>
            <th>Remarks</th>
            <th>Status</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {policyConfigDetails && policyConfigDetails.length ? (
            policyConfigDetails.map((detail) => (
              <tr key={detail.id}>
                <td>{detail.master.policyName}</td>
                <td>{detail.sumInsured}</td>
                <td>{detail.memberCategory.displayName}</td>
                <td>{detail.premiumToPay}</td>
                <td>{detail.remarks}</td>
                <td>{detail.status}</td>
                <td>
                  <button onClick={() => handleEditDetail(detail)}>Edit</button>
                </td>
                <td>
                  <button onClick={() => handleDeleteDetail(detail.id)}>Delete</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7">No data available</td>
            </tr>
          )}
        </tbody>
      </table>

      <form onSubmit={handleSubmitDetail}>
        <div>
          <label htmlFor="masterId">Master ID:</label>
          <input type="text" id="masterId" value={masterId} onChange={(e) => setMasterId(e.target.value)} />
        </div>

        <div>
        <label htmlFor="policy">Policy:</label>
        <select id="policy" value={policyName} onChange={(e) => setPolicyName(e.target.value)}>
          {policyConfigMaster.map((detail) => (
            <option key={detail.id} value={detail.policyName}>
              {detail.policyName}
            </option>
          ))}
        </select>
      </div>

        <div>
          <label htmlFor="sumInsured">Sum Insured:</label>
          <input type="number" id="sumInsured" value={sumInsured} onChange={(e) => setSumInsured(e.target.value)} />
        </div>

        <div>
          <label htmlFor="memberCategory">Member Category:</label>
          <select id="memberCategory" value={memberCategory} onChange={(e) => setMemberCategory(e.target.value)}>
            <option value="">Select Member Category</option>
            {lookUpDetailsMemCategory.map((category) => (
              <option key={category.id} value={category.displayName}>
                {category.displayName}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="premiumToPay">Premium to Pay:</label>
          <input type="number" id="premiumToPay" value={premiumToPay} onChange={(e) => setPremiumToPay(e.target.value)} />
        </div>

        <div>
          <label htmlFor="detailRemarks">Remarks:</label>
          <input type="text" id="detailRemarks" value={detailRemarks} onChange={(e) => setDetailRemarks(e.target.value)} />
        </div>

        <div>
          <label htmlFor="detailStatus">Status:</label>
          <select id="detailStatus" value={detailStatus} onChange={(e) => setDetailStatus(e.target.value)}>
            <option value="ACTIVE">ACTIVE</option>
            <option value="INACTIVE">INACTIVE</option>
          </select>
        </div>

        <button type="submit">{editingDetailId ? 'Update' : 'Save'}</button>
      </form>
    </div>
  );
};

export default MedClaimInsurance;
