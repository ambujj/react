import React from 'react';
  
const Report = (props) => {
  return (
    <div>
      <h2>No Permission for {props.userId}</h2>
    </div>
  );
};
  
export default Report;
