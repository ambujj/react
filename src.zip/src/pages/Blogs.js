import React from 'react';
  
const Blogs = () => {
  return (
    <div>
      <h1>Welcome to MIS Blogs</h1>
    </div>
  );
};
  
export default Blogs;