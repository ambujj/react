import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CommonService from '../services/CommonService';

const LookupDetail = () => {
  const [lookupMaster, setLookupMaster] = useState([]);
  const [lookupDetails, setLookupDetails] = useState([]);
  const [parentLookupMaster, setParentLookupMaster] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredLookupDetails, setFilteredLookupDetails] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [lookupDetailToDelete, setLookupDetailToDelete] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  const [lookupDetail, setLookupDetail] = useState({
    id: '',
    lookupId: '',
    detailCode: '',
    displayName: '',
    description: '',
    status: '',
    parentCode: '',
  });

  useEffect(() => {
    fetchLookupMaster();
    fetchLookupDetails();
  }, []);

  useEffect(() => {
    filterLookupDetails();
  }, [searchQuery, lookupDetail]);

  const fetchLookupMaster = async () => {
    try {
      const response = await CommonService.getAllLookupMaster();
      setLookupMaster(response.data);
      console.log(lookupMaster);
    } catch (error) {
      console.error('Error fetching lookup data:', error);
    }
  };

  const fetchLookupDetails = async () => {
    try {
      const response = await CommonService.getAllLookupDetail();
      setLookupDetails(response.data);
      console.log(lookupDetail);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setLookupDetail((prevLookupDetail) => ({
      ...prevLookupDetail,
      [name]: value,
    }));

    if (name === 'lookupId') {
      const selectedLookup = lookupMaster.find(
        (lookup) => lookup.lookupId === parseInt(value)
      );
      if (selectedLookup && selectedLookup.parentCode) {
        const filteredParentlookupMaster = lookupMaster.filter(
          (lookup) =>
            lookup.lookupId !== parseInt(value) && lookup.status === 'A'
        );
        setParentLookupMaster(filteredParentlookupMaster);
      } else {
        setParentLookupMaster([]);
      }
    }
  };

  const filterLookupDetails = () => {
    const filteredDetails = lookupDetails.filter((detail) => {
      const { detailCode, displayName, description, status } = detail;
      const query = searchQuery.toLowerCase();
      return (
        detailCode.toLowerCase().includes(query) ||
        displayName.toLowerCase().includes(query) ||
        description.toLowerCase().includes(query) ||
        status.toLowerCase().includes(query)
      );
    });
    setFilteredLookupDetails(filteredDetails);
  };

  const resetForm = () => {
    setLookupDetail({
      id: '',
      lookupId: '',
      detailCode: '',
      displayName: '',
      description: '',
      status: 'A',
      parentCode: '',
    });
  };

/*
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await CommonService.saveLookupDetail(lookupDetail);
      setResponseMessage(response.data.message); // Assuming the server response has a 'message' field
      // Reset the form
      resetForm();
    } catch (error) {
      console.error('Error saving lookup data:', error);
    }
  };
  */
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await CommonService.saveLookupDetail(lookupDetail);
      console.log(response.data.message);
      resetForm();
      fetchLookupDetails();
      setSuccessMessage('Successfully Saved Data');
    } catch (error) {
      console.error('Error saving lookup detail:', error);
    }
  };

  const handleEdit = (detail) => {
    setLookupDetail({ ...detail });
    setIsEditing(true);
  };

  const handleUpdateLookupDetail = async () => {
    try {
        console.log(lookupDetail.id);
        console.log(lookupDetail);
      await CommonService.updateLookupDetail(lookupDetail.id, lookupDetail);
      /*resetForm();
      fetchLookupDetails();
      setIsEditing(false);*/
      setSuccessMessage('Data Updated');
    } catch (error) {
      console.error('Error updating lookup detail:', error);
    }
  };

  const handleDeleteConfirmation = (lookupDetail) => {
    setLookupDetailToDelete(lookupDetail);
    setDeleteConfirmation(true);
  };

  const handleDeleteLookupDetail = async () => {
    try {
      await CommonService.deleteLookupDetailById(parseInt(lookupDetailToDelete.id));
      resetForm();
      fetchLookupDetails();
      setDeleteConfirmation(false);
      setSuccessMessage('Selected Data Deleted');
    } catch (error) {
      console.error('Error deleting lookup detail:', error);
    }
  };

  const getParentCodes = () => {
    if (lookupDetail.lookupId) {
      const selectedLookup = lookupMaster.find(
        (lookup) => lookup.lookupId === lookupDetail.lookupId
      );
      if (selectedLookup) {
        const parentCodes = lookupMaster.filter(
          (lookup) =>
            lookup.lookupId !== lookupDetail.lookupId &&
            lookup.status === 'A' &&
            lookup.parentCode > 0
        );
        if (parentCodes.length > 0) {
          return (
            <select
              id="parentCode"
              name="parentCode"
              value={lookupDetail.parentCode}
              onChange={handleInputChange}
            >
              <option value="">Select Parent Code</option>
              {parentCodes.map((lookup) => (
                <option key={lookup.lookupId} value={lookup.lookupId}>
                  {lookup.lookupName}
                </option>
              ))}
            </select>
          );
        }
      }
    }
    return (
      <select disabled>
        <option value="">Select Parent Code</option>
      </select>
    );
  };

  return (
    <div className="lookup-detail-page">
      <h1>Lookup Detail Page</h1>

      {successMessage && <div className="success-message">{successMessage}</div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="lookupId">Lookup ID:</label>
          <select
            id="lookupId"
            name="lookupId"
            value={lookupDetail.lookupId}
            onChange={handleInputChange}
          >
            <option value="">Select Lookup ID</option>
            {lookupMaster.map((lookup) => (
              <option key={lookup.lookupId} value={lookup.lookupId}>
                {lookup.lookupName}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="parentCode">Parent Code</label>
          {getParentCodes()}
        </div>

        <div className="form-group">
          <label htmlFor="detailCode">Detail Code:</label>
          <input
            type="text"
            id="detailCode"
            name="detailCode"
            value={lookupDetail.detailCode}
            onChange={handleInputChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="displayName">Display Name:</label>
          <input
            type="text"
            id="displayName"
            name="displayName"
            value={lookupDetail.displayName}
            onChange={handleInputChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Description:</label>
          <input
            type="text"
            id="description"
            name="description"
            value={lookupDetail.description}
            onChange={handleInputChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="status">Status:</label>
          <select
            id="status"
            name="status"
            value={lookupDetail.status}
            onChange={handleInputChange}
          >
            <option value="">Select Status</option>
            <option value="A">Active</option>
            <option value="X">Inactive</option>
          </select>
        </div>

        {isEditing ? (
          <div className="button-group">
            <button onClick={handleUpdateLookupDetail}>Update Lookup</button>
            <button onClick={() => setIsEditing(false)}>Cancel</button>
          </div>
        ) : (
          <button onClick={handleSubmit}>Add Lookup</button>
        )}

      </form>

      <div>
        <input
          type="text"
          placeholder="Search by detailCode, displayName, description, or status"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <table>
          <thead>
            <tr>
              <th>Detail Code</th>
              <th>Display Name</th>
              <th>Description</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredLookupDetails.map((detail) => (
              <tr key={detail.id}>
                <td>{detail.detailCode}</td>
                <td>{detail.displayName}</td>
                <td>{detail.description}</td>
                <td>{detail.status}</td>
                <td>
                  <button onClick={() => handleEdit(detail)}>Edit</button>
                  <button onClick={() => handleDeleteConfirmation(detail)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {deleteConfirmation && lookupDetailToDelete && (
        <div className="delete-confirmation">
          <div className="delete-confirmation-content">
            <p>Are you sure you want to delete this lookup?</p>
            <div className="button-group">
              <button onClick={handleDeleteLookupDetail}>Yes</button>
              <button onClick={() => setDeleteConfirmation(false)}>No</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LookupDetail;
