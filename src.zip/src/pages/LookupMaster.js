import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CommonService from '../services/CommonService';
import '../css/lookup.css';

const LookupMaster = () => {
  const [lookupData, setLookupData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [newLookup, setNewLookup] = useState({
    lookupId: '',
    lookupName: '',
    lookupDescription: '',
    status: 'A',
    parentCode: null,
  });
  const [isEditing, setIsEditing] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [lookupToDelete, setLookupToDelete] = useState(null);

  useEffect(() => {
    fetchLookupData();
  }, []);

  const fetchLookupData = async () => {
    try {
      const response = await CommonService.getAllLookupMaster();
      setLookupData(response.data);
    } catch (error) {
      console.error('Error fetching lookup data:', error);
    }
  };

  const handleInputChange = (e) => {
    setNewLookup({ ...newLookup, [e.target.name]: e.target.value });
  };

  const handleAddLookup = async () => {
    try {
      await CommonService.saveLookupMaster(newLookup);
      fetchLookupData();
      setNewLookup({
        lookupId: '',
        lookupName: '',
        lookupDescription: '',
        status: 'A',
        parentCode: null,
      });
    } catch (error) {
      console.error('Error adding lookup:', error);
    }
  };

  const handleEditLookup = (lookup) => {
    setNewLookup({ ...lookup });
    setIsEditing(true);
  };

  const handleUpdateLookup = async () => {
    try {
      await CommonService.updateLookupMaster(newLookup.lookupId, newLookup);
      fetchLookupData();
      resetForm();
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating lookup:', error);
    }
  };

  const handleDeleteConfirmation = (lookup) => {
    setLookupToDelete(lookup);
    setDeleteConfirmation(true);
  };
  
  const handleDeleteLookup = async () => {
    try {
      await CommonService.deleteLookupMasterById(lookupToDelete.lookupId);
      fetchLookupData();
      resetForm();
    } catch (error) {
      console.error('Error deleting lookup:', error);
    }
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const filteredLookupData = lookupData.filter((lookup) =>
    lookup.lookupName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const resetForm = () => {
    setNewLookup({
      lookupId: '',
      lookupName: '',
      lookupDescription: '',
      status: 'A',
      parentCode: null,
    });
  };

  return (
    <div className="lookup-master-page">
      <h1>Lookup Master Page</h1>
      <div className="lookup-form">
        <h2>{isEditing ? 'Edit Lookup' : 'Add Lookup'}</h2>
        <div className="input-group">
          <label htmlFor="lookupName">Lookup Name:</label>
          <input
            type="text"
            id="lookupName"
            name="lookupName"
            value={newLookup.lookupName}
            onChange={handleInputChange}
          />
        </div>

        <div className="input-group">
          <label htmlFor="lookupDescription">Lookup Description:</label>
          <input
            type="text"
            id="lookupDescription"
            name="lookupDescription"
            value={newLookup.lookupDescription}
            onChange={handleInputChange}
          />
        </div>

        <div className="input-group">
          <label htmlFor="status">Status:</label>
          <select
            id="status"
            name="status"
            value={newLookup.status}
            onChange={handleInputChange}
          >
            <option value="A">Active</option>
            <option value="X">Inactive</option>
          </select>
        </div>

        <div className="input-group">
          <label htmlFor="parentCode">Parent Code:</label>
          <select
            id="parentCode"
            name="parentCode"
            value={newLookup.parentCode || ''}
            onChange={handleInputChange}
          >
            <option value="">None</option>
            {lookupData.map((lookup) => (
              <option key={lookup.lookupId} value={lookup.lookupId}>
                {lookup.lookupName}
              </option>
            ))}
          </select>
        </div>

        {isEditing ? (
          <div className="button-group">
            <button onClick={handleUpdateLookup}>Update Lookup</button>
            <button onClick={() => setIsEditing(false)}>Cancel</button>
          </div>
        ) : (
          <button onClick={handleAddLookup}>Add Lookup</button>
        )}
      </div>
    <div className="search-container">
        <label htmlFor="searchTerm">Search:</label>
        <input
          type="text"
          id="searchTerm"
          name="searchTerm"
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </div>
      <div className="lookup-list">
        <h2>Lookup List</h2>
        <table>
          <thead>
            <tr>
              <th>Lookup ID</th>
              <th>Lookup Name</th>
              <th>Lookup Description</th>
              <th>Status</th>
              <th>Parent Code</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {filteredLookupData.map((lookup) => (
              <tr key={lookup.lookupId}>
                <td>{lookup.lookupId}</td>
                <td>{lookup.lookupName}</td>
                <td>{lookup.lookupDescription}</td>
                <td>{lookup.status}</td>
                <td>{lookup.parentCode}</td>
                <td>
                  <button onClick={() => handleEditLookup(lookup)}>Edit</button>
                </td>
                <td>  
                  <button onClick={() => handleDeleteConfirmation(lookup)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {deleteConfirmation && lookupToDelete && (
        <div className="delete-confirmation">
          <div className="delete-confirmation-content">
            <p>Are you sure you want to delete this lookup?</p>
            <div className="button-group">
              <button onClick={handleDeleteLookup}>Yes</button>
              <button onClick={() => setDeleteConfirmation(false)}>No</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LookupMaster;