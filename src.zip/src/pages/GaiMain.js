import React, { Component, useState, useEffect, useCallback, Radio, ControlLabel, Dropdown } from "react";
import { Button, FormGroup, FormControl, Col, Row, Form, InputGroup, Alert, Modal, Tooltip } from 'react-bootstrap';
import '../css/form.css';
import '../css/gai.css';
import DataService from '../services/GaiService';
import DatePicker from 'react-datepicker';
import Select from 'react-select';
import dateFormat from "dateformat";
import "react-datepicker/dist/react-datepicker.css";
import moment from "moment";
import { differenceInYears, parse } from "date-fns"
import { Provider } from 'react-redux';
import configData from "../config/urls.json";
import { useSelector, useDispatch } from 'react-redux';


function GaiMain(props) {
  const isEmployed = [
    { label: "Yes", value: "Yes" },
    { label: "No", value: "No" }
  ];
  const relationList = [
    { label: "Self", value: "Self" },
    { label: "Wife", value: "Wife" },
    { label: "Husband", value: "Husband" },
    { label: "Daughter", value: "Daughter" },
    { label: "Son", value: "Son" },
    { label: "Mother", value: "Mother" },
    { label: "Father", value: "Father" },
    { label: "Sister", value: "Sister" },
    { label: "Brother", value: "Brother" },
    { label: "Nephew", value: "Nephew" },
    { label: "Niece", value: "Niece" },
    { label: "Daughter In Law", value: "Daughter In Law" },
    { label: "Son In Law", value: "Son In Law" },
    { label: "Mother In Law", value: "Mother In Law" },
    { label: "Father In Law", value: "Father In Law" },
    { label: "Sister In Law", value: "Sister In Law" },
    { label: "Brother In Law", value: "Brother In Law" },
    { label: "Step - Mother", value: "Step - Mother" },
    { label: "Step - Father", value: "Step - Father" }
  ];
  const [parentsMaxClaimable, setparentsMaxClaimable] = useState(500000);
  const [table3Maximum, setTable3Maximum] = useState(750000);
  const [gai_id, setGai_Id] = useState(0);
  const [emp_code, setEmp_Code] = useState("");
  const [emp_name, setEmp_Name] = useState("");
  const [ext_no, setExt_No] = useState("");
  const [mobile, setMobile] = useState("");
  const [dob, setDob] = useState("");
  const [designation_grade, setDesignation_Grade] = useState("");
  const [dept_section, setDept_Section] = useState("");
  const [grossSalaryPerMonth, setGrossSalaryPerMonth] = useState("");
  const [noMonthsCounted, setNoMonthsCounted] = useState(0);
  const [coverage_table1, setCoverage_Table1] = useState(0);
  const [coverage_table1a, setCoverage_Table1a] = useState(0);
  const [coverage_table2, setCoverage_Table2] = useState(0);
  const [coverage_table3, setCoverage_Table3] = useState(0);
  const [maxcoverage_table3, setMaxCoverage_Table3] = useState(750000);
  const [spouse_name, setSpouse_Name] = useState("");
  const [spouse_dob, setSpouse_Dob] = useState("");
  const [spouse_employed, setSpouse_Employed] = useState("No");
  const [spouse_office, setSpouse_Office] = useState("");
  const [spouse_salary, setSpouse_Salary] = useState(0);
  const [child1_name, setChild1_Name] = useState("");
  const [child1_dob, setChild1_Dob] = useState("");
  const [child1_age, setChild1_Age] = useState(0);
  const [child2_name, setChild2_Name] = useState("");
  const [child2_dob, setChild2_Dob] = useState("");
  const [child2_age, setChild2_Age] = useState(0);
  const [child3_name, setChild3_Name] = useState("");
  const [child3_dob, setChild3_Dob] = useState("");
  const [child3_age, setChild3_Age] = useState(0);
  const [parent1_name, setParent1_Name] = useState("");
  const [parent1_dob, setParent1_Dob] = useState("");
  const [parent1_age, setParent1_Age] = useState(0);
  const [parent2_name, setParent2_Name] = useState("");
  const [parent2_dob, setParent2_Dob] = useState("");
  const [parent2_age, setParent2_Age] = useState(0);
  const [coverage_table1_spouse, setCoverage_Table1_Spouse] = useState(0);
  const [coverage_table1_dep_child1, setCoverage_Table1_Dep_Child1] = useState(0);
  const [coverage_table1_dep_child2, setCoverage_Table1_Dep_Child2] = useState(0);
  const [coverage_table1_dep_child3, setCoverage_Table1_Dep_Child3] = useState(0);
  const [coverage_table1a_spouse, setCoverage_Table1a_Spouse] = useState(0);
  const [coverage_table1a_dep_child1, setCoverage_Table1a_Dep_Child1] = useState(0);
  const [coverage_table1a_dep_child2, setCoverage_Table1a_Dep_Child2] = useState(0);
  const [coverage_table1a_dep_child3, setCoverage_Table1a_Dep_Child3] = useState(0);
  const [coverage_table2_spouse, setCoverage_Table2_Spouse] = useState(0);
  const [coverage_table2_dep_child1, setCoverage_Table2_Dep_Child1] = useState(0);
  const [coverage_table2_dep_child2, setCoverage_Table2_Dep_Child2] = useState(0);
  const [coverage_table2_dep_child3, setCoverage_Table2_Dep_Child3] = useState(0);
  const [coverage_table3_spouse, setCoverage_Table3_Spouse] = useState(0);
  const [coverage_table1a_father, setCoverage_Table1a_Father] = useState(0);
  const [coverage_table1a_mother, setCoverage_Table1a_Mother] = useState(0);
  const [maxcoverage_parents, setMaxcoverage_Parents] = useState(500000);
  const [self_nominee, setSelf_Nominee] = useState("");
  const [self_nominee_relation, setSelf_Nominee_Relation] = useState("");
  const [spouse_nominee, setSpouse_Nominee] = useState("");
  const [spouse_nominee_relation, setSpouse_Nominee_Relation] = useState("");
  const [children_nominee, setChildren_Nominee] = useState("");
  const [children_nominee_relation, setChildren_Nominee_Relation] = useState("");
  const [parents_nominee, setParents_Nominee] = useState("");
  const [parents_nominee_relation, setParents_Nominee_Relation] = useState("");
  const [sscp_nominee, setSscp_Nominee] = useState("");
  const [sscp_nominee_relation, setSscp_Nominee_Relation] = useState("");
  const [signed_date, setSigned_Date] = useState("");
  const [witness_name, setWitness_Name] = useState("");
  const [settlement, setSettlement] = useState("");
  const [status, setStatus] = useState("D");
  const [settled_amount, setSettled_amount] = useState(0);
  const [save_status, setSave_status] = useState("");

  const [cntChildren, setCntChildren] = useState(0);
  const [totalClaimed, setTotalClaimed] = useState(0);
  const [message, setMessage] = useState("");
  const [dependentList, setDependentList] = useState([]);
  const [isValid, setIsValid] = useState(false);
  const [inputValues, setInputValues] = useState(0);

  const [configFinYear, setConfigFinYear] = useState("");
  const [configTable1_Amount, setConfigTable1_Amount] = useState(0);
  const [configTable1a_Amount, setConfigTable1a_Amount] = useState(0);
  const [configTable2_Amount, setConfigTable2_Amount] = useState(0);
  const [configTable3_Amount, setConfigTable3_Amount] = useState(0);

  const [eligibileCoverageSelf, setEligibileCoverageSelf] = useState(0);
  const [eligibileCoverageSpouse, setEligibileCoverageSpouse] = useState(0);
  const [premium, setPremium] = useState(0);

  const [show, setShow] = useState(false);
  const [update, setUpdate] = useState(false);

  /*
  const hideButton = () => {
    setShow(true);
  };
  const [printParams, setPrintParams] = useState([{
    paramCode: null,
    paramType: null,
    paramValue: null,
  }]);

  const incrementCount = useCallback(() => {
    setCntChildren(cntChildren + 1);
    console.log(cntChildren);
  }, [cntChildren])

  */
  
  const fetchGaiConfigData = async () => {
    const configData = await DataService.getGaiConfigById(1);//135865
    //console.log("configData" + JSON.stringify(configData));
    setConfigFinYear(configData.data.fin_year);
    setConfigTable1_Amount(configData.data.table1_amount);
    setConfigTable1a_Amount(configData.data.table1a_amount);
    setConfigTable2_Amount(configData.data.table2_amount);
    setConfigTable3_Amount(configData.data.table3_amount);
  }

  const fetchEmpData = async () => {
    const empData = await DataService.getGaiEmployeeById(props.userId);//135865
    //console.log(JSON.stringify(empData));
    setEmp_Code(empData.data.emp_code);
    setEmp_Name(empData.data.emp_name);
    setExt_No(empData.data.off_tel_extension);
    setMobile(empData.data.mobile);
    setDob(dateFormat(empData.data.dob, "dd-mm-yyyy"));
    setDesignation_Grade(empData.data.erdc_design);
    setDept_Section(empData.data.dept_shortname);
    setGrossSalaryPerMonth(empData.data.total);
    setNoMonthsCounted(empData.data.column2);
  }

  //const [noOfChildren, setNoOfChildren] = useState(0);
  const fetchEmpDependantData = async () => {
    const empDepData = await DataService.getGaiEmpDependants(props.userId);
    //console.log("DEPD LIST " + JSON.stringify(empDepData.data));
    setDependentList(JSON.stringify(empDepData.data));
    const depdList = empDepData.data;
    for (var i = 0; i < depdList.length; i++) {
      if (depdList[i]?.relation == "Wife" || depdList[i]?.relation == "Husband") {
        setSpouse_Name(depdList[i]?.dependant_name);
        setSpouse_Dob(dateFormat(depdList[i]?.depend_dob, "dd-mm-yyyy"));
      }
      if (depdList[i]?.relation == "Father") {
        setParent1_Name(depdList[i]?.dependant_name);
        setParent1_Dob(dateFormat(depdList[i]?.depend_dob, "dd-mm-yyyy"));
      }
      if (depdList[i]?.relation == "Mother") {
        setParent2_Name(depdList[i]?.dependant_name);
        setParent2_Dob(dateFormat(depdList[i]?.depend_dob, "dd-mm-yyyy"));
      }
      if (depdList[i]?.relation == "Daughter" || depdList[i]?.relation == "Son") {
        if (i == 0) {
          setChild1_Name(depdList[i]?.dependant_name);
          setChild1_Dob(dateFormat(depdList[i]?.depend_dob, "dd-mm-yyyy"));
        }
        else if (i == 1) {
          setChild2_Name(depdList[i]?.dependant_name);
          setChild2_Dob(dateFormat(depdList[i]?.depend_dob, "dd-mm-yyyy"));
        }
        else if (i == 2) {
          setChild3_Name(depdList[i]?.dependant_name);
          setChild3_Dob(dateFormat(depdList[i]?.depend_dob, "dd-mm-yyyy"));
        }
      }
    }
  };
  
  const fetchGaiData = async () => {
    const gaiData = await DataService.getGaiByEmpId(props.userId);//135865
    const gaiData1 = gaiData.data;
    const date = Date || null // set date to null if myDate is null or undefined
    //console.log("gaiData-------11111111111" + JSON.stringify(gaiData1));
    setGai_Id(gaiData1.gai_id);
    if (gaiData1.gai_id > 0) {
      setShow(true);
      setUpdate(true);
      fetchGaiConfigData();
      setConfigFinYear(gaiData1.fin_year);
      setEmp_Name(gaiData1.emp_name);
      setEmp_Code(gaiData1.emp_code);
      setExt_No(gaiData1.ext_no);
      setMobile(gaiData1.mobile);
      setDob(dateFormat(gaiData1.dob, "dd-mm-yyyy"));
      setDesignation_Grade(gaiData1.designation_grade);
      setDept_Section(gaiData1.dept_section);
      setGrossSalaryPerMonth(gaiData1.monthly_gross);
      setNoMonthsCounted(gaiData1.salary_months);
      //setTotalMonthsSalary(gaiData1.salary_months);

      setCoverage_Table1(gaiData1.coverage_table1);
      setCoverage_Table1a(gaiData1.coverage_table1a);
      setCoverage_Table2(gaiData1.coverage_table2);
      setCoverage_Table3(gaiData1.coverage_table3);
      setSpouse_Name(gaiData1.spouse_name);
      //setDob(dateFormat(gaiData1.dob, "dd-mm-yyyy"));
      setSpouse_Dob(gaiData1.spouse_dob ? dateFormat(gaiData1.spouse_dob, "dd-mm-yyyy") : '');
      setSpouse_Employed(gaiData1.spouse_employed);
      setSpouse_Office(gaiData1.spouse_office);
      setSpouse_Salary(gaiData1.spouse_salary);
      setChild1_Name(gaiData1.child1_name);
      setChild1_Dob(gaiData1.child1_dob ? dateFormat(gaiData1.child1_dob, "dd-mm-yyyy") : '');
      setChild2_Name(gaiData1.child2_name);
      setChild2_Dob(gaiData1.child2_dob ? dateFormat(gaiData1.child2_dob, "dd-mm-yyyy") : '');
      setChild3_Name(gaiData1.child3_name);
      setChild3_Dob(gaiData1.child3_dob ? dateFormat(gaiData1.child3_dob, "dd-mm-yyyy") : '');
      setParent1_Name(gaiData1.parent1_name);
      setParent1_Dob(gaiData1.parent1_dob ? dateFormat(gaiData1.parent1_dob, "dd-mm-yyyy") : '');
      setParent2_Name(gaiData1.parent2_name);
      setParent2_Dob(gaiData1.parent2_dob ? dateFormat(gaiData1.parent2_dob, "dd-mm-yyyy") : '');
      setCoverage_Table1_Spouse(gaiData1.coverage_table1_spouse);
      setCoverage_Table1_Dep_Child1(gaiData1.coverage_table1_dep_child1);
      setCoverage_Table1_Dep_Child2(gaiData1.coverage_table1_dep_child2);
      setCoverage_Table1_Dep_Child3(gaiData1.coverage_table1_dep_child3);
      setCoverage_Table1a_Spouse(gaiData1.coverage_table1a_spouse);
      setCoverage_Table1a_Dep_Child1(gaiData1.coverage_table1a_dep_child1);
      setCoverage_Table1a_Dep_Child2(gaiData1.coverage_table1a_dep_child2);
      setCoverage_Table1a_Dep_Child3(gaiData1.coverage_table1a_dep_child3);
      setCoverage_Table2_Spouse(gaiData1.coverage_table2_spouse);
      setCoverage_Table2_Dep_Child1(gaiData1.coverage_table2_dep_child1);
      setCoverage_Table2_Dep_Child2(gaiData1.coverage_table2_dep_child2);
      setCoverage_Table2_Dep_Child3(gaiData1.coverage_table2_dep_child3);

      setCoverage_Table3_Spouse(gaiData1.coverage_table3_spouse);
      setCoverage_Table1a_Father(gaiData1.coverage_table1a_father);
      setCoverage_Table1a_Mother(gaiData1.coverage_table1a_mother);
      setSelf_Nominee(gaiData1.self_nominee);
      setSelf_Nominee_Relation(gaiData1.self_nominee_relation);
      setSpouse_Nominee(gaiData1.spouse_nominee);
      setSpouse_Nominee_Relation(gaiData1.spouse_nominee_relation);
      setChildren_Nominee(gaiData1.children_nominee);
      setChildren_Nominee_Relation(gaiData1.children_nominee_relation);
      setParents_Nominee(gaiData1.parents_nominee);
      setParents_Nominee_Relation(gaiData1.parents_nominee_relation);
      setSscp_Nominee(gaiData1.sscp_nominee);
      setSscp_Nominee_Relation(gaiData1.sscp_nominee_relation);
      setSigned_Date(dateFormat(gaiData1.signed_date, "dd-mm-yyyy"));
      //setSigned_Date(gaiData1.signed_date ? dateFormat(gaiData1.signed_date, "dd-mm-yyyy"):'');
      setWitness_Name(gaiData1.witness_name);
      setSettlement(gaiData1.settlement);
      setStatus(gaiData1.status);
      setSettled_amount(gaiData1.settled_amount);
      //setSalary_months(gaiData1.salary_months);
      //console.log("Date ="+dateFormat(gaiData1.signed_date, "dd-mm-yyyy"));

      var tot = Number(gaiData1.coverage_table1) + Number(gaiData1.coverage_table1a) + Number(gaiData1.coverage_table2) + Number(gaiData1.coverage_table3) + Number(gaiData1.coverage_table1_spouse) + Number(gaiData1.coverage_table1_dep_child1) + Number(gaiData1.coverage_table1_dep_child2) +
        Number(gaiData1.coverage_table1_dep_child3) + Number(gaiData1.coverage_table1a_spouse) + Number(gaiData1.coverage_table1a_dep_child1) + Number(gaiData1.coverage_table1a_dep_child2) + Number(gaiData1.coverage_table1a_dep_child3) +
        Number(gaiData1.coverage_table2_spouse) + Number(gaiData1.coverage_table2_dep_child1) + Number(gaiData1.coverage_table2_dep_child2) + Number(gaiData1.coverage_table2_dep_child3) + Number(gaiData1.coverage_table3_spouse) + Number(gaiData1.coverage_table1a_father) +
        Number(gaiData1.coverage_table1a_mother);

      console.log("Total =" + tot);
      setTotalClaimed(tot);
      calculate_premium();
    }
    else {
      //console.log("Total ="+tot);
      setTotalClaimed(0);
      fetchEmpData();
      fetchGaiConfigData();
      fetchEmpDependantData();
    }
    console.log("GAI ID =" + gai_id)
    console.log(JSON.stringify(gaiData1.gai_id));
  }

  useEffect(() => {
    fetchGaiData(props.userId);
  }, []);

  useEffect(() => {
    setPremium((coverage_table1 + coverage_table1_spouse) * configTable1_Amount + (coverage_table1a + coverage_table1a_spouse) * configTable1a_Amount);
  }, [coverage_table1, coverage_table1_spouse, configTable1_Amount, coverage_table1a, coverage_table1a_spouse, configTable2_Amount]);

  /*
  
  const calcTotalClaimed = ()=>{
    let totClaimed =0;
    setTotalClaimed(parseInt(coverage_table1)+parseInt(coverage_table1a)+parseInt(coverage_table2)+parseInt(coverage_table3)+parseInt(coverage_table1_spouse)+parseInt(coverage_table1_dep_child1)+parseInt(coverage_table1_dep_child2)+
                  parseInt(coverage_table1_dep_child3)+parseInt(coverage_table1a_spouse)+parseInt(coverage_table1a_dep_child1)+parseInt(coverage_table1a_dep_child2)+parseInt(coverage_table1a_dep_child3)+
                  parseInt(coverage_table2_spouse)+parseInt(coverage_table2_dep_child1)+parseInt(coverage_table2_dep_child2)+parseInt(coverage_table2_dep_child3)+parseInt(coverage_table3_spouse)+parseInt(coverage_table1a_father)+
                  parseInt(coverage_table1a_mother));
    //setTotalClaimed(totClaimed); 
    console.log("1 ="+totalClaimed);
    return totClaimed;
  };
  
  
  */

  const autoSetValues = () => {
    //console.log("A = "+monthly_gross)
    //console.log("B = "+totalMonthsSalary)
    let totClaimableAmount = grossSalaryPerMonth * noMonthsCounted;
    let selfAssignedAmt = totClaimableAmount / 2;
    let spouseAssignedAmt = totClaimableAmount / 2;
    let parentsAssignedAmt = parentsMaxClaimable;
    let childAssignedAmt = totClaimableAmount / 4;
    if (totClaimableAmount < table3Maximum)
      setCoverage_Table3(totClaimableAmount);
    else
      setCoverage_Table3(table3Maximum);
    // calcTotalClaimed();
    //setTotalClaimed(calcTotalClaimed)
    /*let abc=calcTotalClaimed();
    console.log("2 ="+abc);  
    console.log("C = "+totClaimableAmount)
    console.log("totalClaimed==="+totalClaimed);  */
  }


  const onChangeName = (e) => {
    let val = e.target.value
    setEmp_Name(val);
  }

  const onChangeExtNo = (e) => {
    let val = e.target.value
    setExt_No(val);
  }

  const onChangeMobile = (e) => {
    let val = e.target.value
    setMobile(val);
  }

  const onChangeDob = (e) => {
    let val = e.target.value
    setDob(val);
  }
  const onChangeDesignation = (e) => {
    let val = e.target.value
    setDesignation_Grade(val);
  }
  const onChangeDeptSection = (e) => {
    let val = e.target.value
    setDept_Section(val);
  }
  const onChangeMonthlyGross = (e) => {
    let val = e.target.value
    setGrossSalaryPerMonth(val);
  }
  const onChangeSpouseName = (e) => {
    let val = e.target.value
    setSpouse_Name(val);
  }
  const onChangeSpouseDob = (e) => {
    let val = e.target.value
    setSpouse_Dob(val);
  }
  const onChangeSpouseEmployed = (e) => {
    let val = e.target.value
    //var spouseOrg = document.getElementById("spouseOrganisation");
    if (val === "Yes") {
      document.getElementById("spouseOrganisation").disabled = false;
      document.getElementById("spouseSalary").disabled = false;
      document.getElementById("spouseTable3").disabled = false;
      document.getElementById("spouseTable1").disabled = false;
      document.getElementById("spouseTable1a").disabled = false;
      document.getElementById("spouseTable2").disabled = false;
      document.getElementById("spouseTable3").disabled = false;

    }
    else {
      document.getElementById("spouseOrganisation").disabled = true;
      document.getElementById("spouseSalary").disabled = true;
      document.getElementById("spouseTable3").disabled = true;

      setCoverage_Table1_Spouse(0);
      setCoverage_Table1a_Spouse(0);
      setCoverage_Table2_Spouse(0);
      setCoverage_Table3_Spouse(0);
      setSpouse_Salary(0);
      setSpouse_Office('');

      /*document.getElementById("spouseTable1").value =0;
      document.getElementById("spouseTable1a").value =0;
      document.getElementById("spouseTable2").value =0;
      document.getElementById("spouseTable3").value =0;*/

    }
    setSpouse_Employed(val);
  }
  const onChangeSpouse_Office = (e) => {
    let val = e.target.value
    setSpouse_Office(val);
  }
  const onChangeSpouseSalary = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setSpouse_Salary(val);
    }
  }
  const onChangeChild1Name = (e) => {
    let val = e.target.value
    setChild1_Name(val);
  }
  const onChangeChild1Dob = (e) => {
    let val = e.target.value
    setChild1_Dob(val);
  }
  const onChangeChild2Name = (e) => {
    let val = e.target.value
    setChild2_Name(val);
  }
  const onChangeChild2Dob = (e) => {
    let val = e.target.value
    setChild2_Dob(val);
  }
  const onChangeChild3Name = (e) => {
    let val = e.target.value
    setChild3_Name(val);
  }
  const onChangeChild3Dob = (e) => {
    let val = e.target.value
    setChild3_Dob(val);
  }
  const onChangeParemt1Name = (e) => {
    let val = e.target.value
    setParent1_Name(val);
  }
  const onChangeParent1Dob = (e) => {
    let val = e.target.value
    setParent1_Dob(val);
  }
  const onChangeParent2Name = (e) => {
    let val = e.target.value
    setParent2_Name(val);
  }
  const onChangeParent2Dob = (e) => {
    let val = e.target.value
    setParent2_Dob(val);
  }
  const onChangeCoverageTable1 = (e) => {
    let val = parseInt(e.target.value)
    const regex = /^[0-9\b]+$/; // regular expression to match numbers only
    if (val === '' || regex.test(val)) {
      console.log("Current = " + val);
      setCoverage_Table1(val);
    }

  }
  const onChangeCoverageTable1a = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1a(val);
    }
  }
  const onChangeCoverageTable2 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table2(val);
    }
  }
  const onChangeCoverageTable3 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      if (validateMaxValue(val, maxcoverage_table3)) {
        setCoverage_Table3(val);
      }
    }
  }
  const onChangeTable1Spouse = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1_Spouse(val);
    }
  }
  const onChangeTable1DepChild1 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1_Dep_Child1(val);
    }
  }
  const onChangeTable1DepChild2 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1_Dep_Child2(val);
    }
  }
  const onChangeTable1DepChild3 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1_Dep_Child3(val);
    }
  }
  const onChangeTable1aSpouse = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1a_Spouse(val);
    }
  }
  const onChangeTable1aDepChild1 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1a_Dep_Child1(val);
    }
  }
  const onChangeTable1aDepChild2 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1a_Dep_Child2(val);
    }
  }
  const onChangeTable1aDepChild3 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table1a_Dep_Child3(val);
    }
  }
  const onChangeTable2Spouse = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table2_Spouse(val);
    }
  }
  const onChangeTable2DepChild1 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table2_Dep_Child1(val);
    }
  }
  const onChangeTable2DepChild2 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table2_Dep_Child2(val);
    }
  }
  const onChangeTable2DepChild3 = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      setCoverage_Table2_Dep_Child3(val);
    }
  }
  const onChangeTable3Spouse = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      if (spouse_employed == "Yes") {
        if (validateMaxValue(val, maxcoverage_table3)) {
          setCoverage_Table3_Spouse(val);
        }
      }
      else {
        if (validateMaxValue(val, maxcoverage_table3 / 2)) {
          setCoverage_Table3_Spouse(val);
        }
      }
    }
  }



  const onChangeTable1aFather = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      if (validateMaxValue(val, maxcoverage_parents)) {
        setCoverage_Table1a_Father(val);
      }
    }
  }
  const onChangeTable1aMother = (e) => {
    let val = e.target.value
    const regex = /^[0-9\b]+$/;
    if (val === '' || regex.test(val)) {
      if (validateMaxValue(val, maxcoverage_parents)) {
        setCoverage_Table1a_Mother(val);
      }
    }

  }
  const onChangeSelfNominee = (e) => {
    let val = e.target.value
    setSelf_Nominee(val);
  }
  const onChangeSelfNomineeRelation = (e) => {
    let val = e.target.value
    setSelf_Nominee_Relation(val);
  }
  const onChangeSpouseNominee = (e) => {
    let val = e.target.value
    setSpouse_Nominee(val);
  }
  const onChangeSpouseNomineeRelation = (e) => {
    let val = e.target.value
    setSpouse_Nominee_Relation(val);
  }
  const onChangeChildNominee = (e) => {
    let val = e.target.value
    setChildren_Nominee(val);
  }
  const onChangeChildNomineeRelation = (e) => {
    let val = e.target.value
    setChildren_Nominee_Relation(val);
  }
  const onChangeParentNominee = (e) => {
    let val = e.target.value
    setParents_Nominee(val);
  }
  const onChangeParentNomineeRelation = (e) => {
    let val = e.target.value
    setParents_Nominee_Relation(val);
  }
  const onChangeSscpNominee = (e) => {
    let val = e.target.value
    setSscp_Nominee(val);
  }
  const onChangeSscpNomineeRelation = (e) => {
    let val = e.target.value
    setSscp_Nominee_Relation(val);
  }
  const onChangeSignedDate = (date) => {
    let val = dateFormat(date, "dd-mm-yyyy");
    setSigned_Date(val);
  }

  const onChangeWitness = (e) => {
    let val = e.target.value
    setWitness_Name(val);
  }

  function handleInputChange(event) {
    const val = event.target.value;
    const regex = /^[0-9]*$/;
    const tempClaimable = parseInt(noMonthsCounted) * parseInt(grossSalaryPerMonth);
    //const sum = parseInt(coverage_table1)+parseInt(coverage_table1a)+parseInt(coverage_table2)+parseInt(coverage_table3);

    //console.log("tempClaimable "+tempClaimable);
    //console.log("Increased Vlue ----------------"+(document.getElementById("coverage_table1").value ? document.getElementById("coverage_table1").value:0))
    const sum = parseInt(document.getElementById("coverage_table1").value ? document.getElementById("coverage_table1").value : 0) + parseInt(document.getElementById("coverage_table1a").value ? document.getElementById("coverage_table1a").value : 0) + parseInt(document.getElementById("coverage_table2").value ? document.getElementById("coverage_table2").value : 0) + parseInt(document.getElementById("coverage_table3").value ? document.getElementById("coverage_table3").value : 0);
    console.log("sum " + sum);
    /* 
      const sum = parseInt(coverage_table1)+parseInt(coverage_table1a)+parseInt(coverage_table2)+parseInt(coverage_table3)+parseInt(coverage_table1_spouse)+parseInt(coverage_table1_dep_child1)+parseInt(coverage_table1_dep_child2)+
                parseInt(coverage_table1_dep_child3)+parseInt(coverage_table1a_spouse)+parseInt(coverage_table1a_dep_child1)+parseInt(coverage_table1a_dep_child2)+parseInt(coverage_table1a_dep_child3)+
                parseInt(coverage_table2_spouse)+parseInt(coverage_table2_dep_child1)+parseInt(coverage_table2_dep_child2)+parseInt(coverage_table2_dep_child3)+parseInt(coverage_table3_spouse)+parseInt(coverage_table1a_father)+
                parseInt(coverage_table1a_mother);
   
   if (sum >= tempClaimable) {
      event.target.value = '';
      alert('Total Claimable Amount Exceeds !');      
      setCoverage_Table1(0); 
    } else {
*/
    //console.log("event.target.name ="+event.target.name);
    //console.log("event.target.value ="+event.target.value);
    switch (event.target.name) {
      case 'coverage_table1':
        if (val === '' || regex.test(val)) {
          if (sum > tempClaimable) {
            alert('Total Claimable Amount Exceeds !');
            return;
          }
          else {
            console.log("Current = " + val);
            //setTotalClaimed(totalClaimed-coverage_table1+val);   

            if (val.trim() === "" || val === null) {
              setCoverage_Table1(0);
            }
            else {
              setCoverage_Table1(val);
            }
            //console.log("Length===="+"document.getElementById="+document.getElementById("spouseName").value.length)
            if (document.getElementById("spouseName").value.length > 2) {
              // console.log("Length====Hiiiiiii");
              setCoverage_Table1_Spouse(val / 2);
              document.getElementById("spouseTable1").disabled = false;
            }
            if (document.getElementById("childName1").value.length > 2) {
              setCoverage_Table1_Dep_Child1(val / 4);
              document.getElementById("child1Table1").disabled = false;
            }
            if (document.getElementById("childName2").value.length > 2) {
              setCoverage_Table1_Dep_Child2(val / 4);
              document.getElementById("child2Table1").disabled = false;
            }
            if (document.getElementById("childName3").value.length > 2) {
              setCoverage_Table1_Dep_Child3(val / 4);
              document.getElementById("child3Table1").disabled = false;
            }
            if (document.getElementById("parentName1").value.length > 2) {
              document.getElementById("parent1Table1a").disabled = false;
            }
            if (document.getElementById("parentName2").value.length > 2) {
              document.getElementById("parent2Table1a").disabled = false;
            }

          }
        }
        break;
      case 'coverage_table1a':
        if (val === '' || regex.test(val)) {
          if (sum > tempClaimable) {
            alert('Total Claimable Amount Exceeds !');
            return;
          }
          else {
            if (val.trim() === "" || val === null) {
              setCoverage_Table1a(0);
            }
            else {
              setCoverage_Table1a(val);
            }
            //console.log("document.getElementById="+document.getElementById("spouseName").value.length)
            if (document.getElementById("spouseName").value.length > 2) {
              setCoverage_Table1a_Spouse(val / 2);
              document.getElementById("spouseTable1a").disabled = false;
            }
            if (document.getElementById("childName1").value.length > 2) {
              setCoverage_Table1a_Dep_Child1(val / 4);
              document.getElementById("child1Table1a").disabled = false;
            }
            if (document.getElementById("childName2").value.length > 2) {
              setCoverage_Table1a_Dep_Child2(val / 4);
              document.getElementById("child2Table1a").disabled = false;
            }
            if (document.getElementById("childName3").value.length > 2) {
              setCoverage_Table1a_Dep_Child3(val / 4);
              document.getElementById("child3Table1a").disabled = false;
            }
            if (document.getElementById("parentName1").value.length > 2) {
              setCoverage_Table1a_Father(500000);
              document.getElementById("parent1Table1a").disabled = false;
            }
            if (document.getElementById("parentName2").value.length > 2) {
              setCoverage_Table1a_Mother(500000);
              document.getElementById("parent2Table1a").disabled = false;
            }

          }
        }
        break;
      case 'coverage_table2':
        if (val === '' || regex.test(val)) {
          if (sum > tempClaimable) {
            alert('Total Claimable Amount Exceeds !');
            return;
          }
          else {
            if (val.trim() === "" || val === null) {
              setCoverage_Table2(0);
            }
            else {
              setCoverage_Table2(val);
            }
            //console.log("document.getElementById="+document.getElementById("spouseName").value.length)
            if (document.getElementById("spouseName").value.length > 2) {
              setCoverage_Table2_Spouse(val / 2);
              document.getElementById("spouseTable2").disabled = false;
            }
            if (document.getElementById("childName1").value.length > 2) {
              setCoverage_Table2_Dep_Child1(val / 4);
              document.getElementById("child1Table2").disabled = false;
            }
            if (document.getElementById("childName2").value.length > 2) {
              setCoverage_Table2_Dep_Child2(val / 4);
              document.getElementById("child2Table2").disabled = false;
            }
            if (document.getElementById("childName3").value.length > 2) {
              setCoverage_Table2_Dep_Child3(val / 4);
              document.getElementById("child3Table2").disabled = false;
            }
            if (document.getElementById("parentName1").value.length > 2) {
              document.getElementById("parent1Table1a").disabled = false;
            }
            if (document.getElementById("parentName2").value.length > 2) {
              document.getElementById("parent2Table1a").disabled = false;
            }

          }
        }
        break;
      case 'coverage_table3':
        if (val === '' || regex.test(val)) {
          if (sum > tempClaimable) {
            alert('Total Claimable Amount Exceeds !');
            return;
          }
          else {
            console.log("Current = " + val);
            //setTotalClaimed(totalClaimed-coverage_table1+val);        
            if (validateMaxValue(val, maxcoverage_table3)) {
              if (val.trim() === "" || val === null) {
                setCoverage_Table3(0);
              }
              else {
                setCoverage_Table3(val);
              }
            }
            //console.log("document.getElementById="+document.getElementById("spouseName").value.length)
            if (document.getElementById("spouseName").value.length > 2) {
              document.getElementById("spouseTable2").disabled = false;
            }
            if (document.getElementById("childName1").value.length > 2) {
              document.getElementById("child1Table2").disabled = false;
            }
            if (document.getElementById("childName2").value.length > 2) {
              document.getElementById("child2Table2").disabled = false;
            }
            if (document.getElementById("childName3").value.length > 2) {
              document.getElementById("child3Table2").disabled = false;
            }
            if (document.getElementById("parentName1").value.length > 2) {
              document.getElementById("parent1Table1a").disabled = false;
            }
            if (document.getElementById("parentName2").value.length > 2) {
              document.getElementById("parent2Table1a").disabled = false;
            }

          }

        }
        break;
      case 'spouseTable1':
        if (val === '' || regex.test(val)) {
          if (val.trim() === "" || val === null) {
            setCoverage_Table1_Spouse(0);
            return;
          }
          if (spouse_employed === "No") {
            if (val > coverage_table1 / 2) {
              alert('Total Claimable Amount is 50% of Employee !');
              return;
            }
            else {
              //console.log("Current = "+val);           
              setCoverage_Table1_Spouse(val);
              document.getElementById("spouseTable1").disabled = false;
              //setTotalClaimed(totalClaimed-coverage_table1a_spouse+val); 
            }
          }
          else {
            var spousSal = 0;
            if (parseInt(document.getElementById("spouseSalary").value) > 0)
              spousSal = parseInt(document.getElementById("spouseSalary").value);
            const spouseEligibility = parseInt(noMonthsCounted) * spousSal;
            const sum1 = parseInt(document.getElementById("spouseTable1").value ? document.getElementById("spouseTable1").value : 0) + parseInt(document.getElementById("spouseTable1a").value ? document.getElementById("spouseTable1a").value : 0) + parseInt(document.getElementById("spouseTable2").value ? document.getElementById("spouseTable2").value : 0) + parseInt(document.getElementById("spouseTable3").value ? document.getElementById("spouseTable3").value : 0);

            console.log("sum  1=" + sum1)//parseInt(document.getElementById("spouseTable1").value ));
            console.log("spouseEligibility =" + spouseEligibility);

            if (sum1 > spouseEligibility) {
              alert('Total Claimable Amount Exceeds !');
              return;
            }
            else {
              //console.log("Current = "+val);   
              //setTotalClaimed(totalClaimed-coverage_table1a_spouse+val);        
              setCoverage_Table1_Spouse(val);
              document.getElementById("spouseTable1").disabled = false;
            }
          }



        }
        break;
      case 'child1Table1':
        if (val === '' || regex.test(val)) {
          if (val > coverage_table1 / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);     
            if (val.trim() === "" || val === null) {
              setCoverage_Table1_Dep_Child1(0);
            }
            else {
              setCoverage_Table1_Dep_Child1(val);
            }

            //setTotalClaimed(totalClaimed-coverage_table1_dep_child1+val); 
          }
        }
        break;
      case 'child2Table1':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1_Dep_Child2(0);
          return;
        }

        if (regex.test(val)) {
          if (val > coverage_table1 / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table1_Dep_Child2(val);
            //  setTotalClaimed(totalClaimed-coverage_table1_dep_child2+val);
          }
        }
        break;
      case 'child3Table1':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1_Dep_Child3(0);
          return;
        }
        if (regex.test(val)) {
          if (val > coverage_table1 / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table1_Dep_Child3(val);
            // setTotalClaimed(totalClaimed-coverage_table1_dep_child3+val);
          }

        }
        break;

      case 'spouseTable1a':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1a_Spouse(0);
          return;
        }
        if (regex.test(val)) {

          if (spouse_employed === "No") {
            if (val > coverage_table1a / 2) {
              alert('Total Claimable Amount is 50% of Employee !');
              return;
            }
            else {
              //console.log("Current = "+val);           
              setCoverage_Table1a_Spouse(val);
              document.getElementById("spouseTable1a").disabled = false;
              //setTotalClaimed(totalClaimed-coverage_table1a_spouse+val); 
            }
          }
          else {
            var spousSal = 0;
            if (parseInt(document.getElementById("spouseSalary").value) > 0)
              spousSal = parseInt(document.getElementById("spouseSalary").value);
            const spouseEligibility = parseInt(noMonthsCounted) * spousSal;
            const sum1 = parseInt(document.getElementById("spouseTable1").value ? document.getElementById("spouseTable1").value : 0) + parseInt(document.getElementById("spouseTable1a").value ? document.getElementById("spouseTable1a").value : 0) + parseInt(document.getElementById("spouseTable2").value ? document.getElementById("spouseTable2").value : 0) + parseInt(document.getElementById("spouseTable3").value ? document.getElementById("spouseTable3").value : 0);

            console.log("sum  1=" + sum1)//parseInt(document.getElementById("spouseTable1").value ));
            console.log("spouseEligibility =" + spouseEligibility);

            if (sum1 > spouseEligibility) {
              alert('Total Claimable Amount Exceeds !');
              return;
            }
            else {
              //console.log("Current = "+val);   
              //setTotalClaimed(totalClaimed-coverage_table1a_spouse+val);        
              setCoverage_Table1a_Spouse(val);
              document.getElementById("spouseTable1a").disabled = false;
            }
          }

        }
        break;
      case 'child1Table1a':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1a_Dep_Child1(0);
          return;
        }
        if (regex.test(val)) {
          if (val > coverage_table1a / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table1a_Dep_Child1(val);
            //setTotalClaimed(totalClaimed-coverage_table1a_dep_child1+val);  
          }
        }
        break;
      case 'child2Table1a':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1a_Dep_Child2(0);
          return;
        }
        if (regex.test(val)) {
          if (val > coverage_table1a / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table1a_Dep_Child2(val);
            //setTotalClaimed(totalClaimed-coverage_table1a_dep_child2+val);  
          }
        }
        break;
      case 'child3Table1a':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1a_Dep_Child3(0);
          return;
        }
        if (regex.test(val)) {
          if (val > coverage_table1a / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table1a_Dep_Child3(val);
            //setTotalClaimed(totalClaimed-coverage_table1a_dep_child3+val);    
          }
        }
        break;

      case 'spouseTable2':
        if (val.trim() === "" || val === null) {
          setCoverage_Table2_Spouse(0);
          return;
        }
        if (regex.test(val)) {

          if (spouse_employed === "No") {
            if (val > coverage_table2 / 2) {
              alert('Total Claimable Amount is 50% of Employee !');
              return;
            }
            else {
              //console.log("Current = "+val);           
              setCoverage_Table2_Spouse(val);
              document.getElementById("spouseTable2").disabled = false;
              //setTotalClaimed(totalClaimed-coverage_table1a_spouse+val); 
            }
          }
          else {
            var spousSal = 0;
            if (parseInt(document.getElementById("spouseSalary").value) > 0)
              spousSal = parseInt(document.getElementById("spouseSalary").value);
            const spouseEligibility = parseInt(noMonthsCounted) * spousSal;
            const sum1 = parseInt(document.getElementById("spouseTable1").value ? document.getElementById("spouseTable1").value : 0) + parseInt(document.getElementById("spouseTable1a").value ? document.getElementById("spouseTable1a").value : 0) + parseInt(document.getElementById("spouseTable2").value ? document.getElementById("spouseTable2").value : 0) + parseInt(document.getElementById("spouseTable3").value ? document.getElementById("spouseTable3").value : 0);

            console.log("sum  1=" + sum1)//parseInt(document.getElementById("spouseTable1").value ));
            console.log("spouseEligibility =" + spouseEligibility);

            if (sum1 > spouseEligibility) {
              alert('Total Claimable Amount Exceeds !');
              return;
            }
            else {
              //console.log("Current = "+val);   
              //setTotalClaimed(totalClaimed-coverage_table1a_spouse+val);        
              setCoverage_Table2_Spouse(val);
              document.getElementById("spouseTable2").disabled = false;
            }
          }


        }
        break;
      case 'child1Table2':
        if (val.trim() === "" || val === null) {
          setCoverage_Table2_Dep_Child1(0);
          return;
        }
        if (regex.test(val)) {
          if (val > coverage_table2 / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table2_Dep_Child1(val);
            //setTotalClaimed(totalClaimed-coverage_table2_dep_child1+val);     
          }

        }
        break;
      case 'child2Table2':
        if (val.trim() === "" || val === null) {
          setCoverage_Table2_Dep_Child2(0);
          return;
        }
        if (regex.test(val)) {
          if (val > coverage_table2 / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table2_Dep_Child2(val);
            //setTotalClaimed(totalClaimed-coverage_table2_dep_child2+val);      
          }
        }
        break;
      case 'child3Table2':
        if (val.trim() === "" || val === null) {
          setCoverage_Table2_Dep_Child3(0);
          return;
        }
        if (regex.test(val)) {
          if (val > coverage_table2 / 4) {
            alert('Total Claimable Amount is 25% of Employee !');
            return;
          }
          else {
            //console.log("Current = "+val);           
            setCoverage_Table2_Dep_Child3(val);
            //setTotalClaimed(totalClaimed-coverage_table2_dep_child3+val);    
          }
        }
        break;
      case 'spouseTable3':
        if (val.trim() === "" || val === null) {
          setCoverage_Table3_Spouse(0);
          return;
        }
        if (regex.test(val)) {
          if (spouse_employed == "Yes") {
            var spousSal = 0;
            if (parseInt(document.getElementById("spouseSalary").value) > 0)
              spousSal = parseInt(document.getElementById("spouseSalary").value);
            const spouseEligibility = parseInt(noMonthsCounted) * spousSal;
            const sum1 = parseInt(document.getElementById("spouseTable1").value ? document.getElementById("spouseTable1").value : 0) + parseInt(document.getElementById("spouseTable1a").value ? document.getElementById("spouseTable1a").value : 0) + parseInt(document.getElementById("spouseTable2").value ? document.getElementById("spouseTable2").value : 0) + parseInt(document.getElementById("spouseTable3").value ? document.getElementById("spouseTable3").value : 0);

            console.log("sum  1=" + sum1)//parseInt(document.getElementById("spouseTable1").value ));
            console.log("spouseEligibility =" + spouseEligibility);

            if (sum1 > spouseEligibility) {
              alert('Total Claimable Amount Exceeds !');
              return;
            }

            if (validateMaxValue(val, maxcoverage_table3)) {
              setCoverage_Table3_Spouse(val);
              document.getElementById("spouseTable3").disabled = false;
              //setTotalClaimed(totalClaimed-coverage_table3_spouse+val);
            }
          }
        }
        break;

      case 'parent1Table1a':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1a_Father(0);
          return;
        }
        if (regex.test(val)) {
          if (validateMaxValue(val, maxcoverage_parents)) {
            setCoverage_Table1a_Father(val);
            //setTotalClaimed(totalClaimed-coverage_table1a_father+val);
          }
          console.log("Current = " + val);

        }
        break;
      case 'parent2Table1a':
        if (val.trim() === "" || val === null) {
          setCoverage_Table1a_Mother(0);
          return;
        }
        if (regex.test(val)) {
          if (validateMaxValue(val, maxcoverage_parents)) {
            setCoverage_Table1a_Mother(val);
            //setTotalClaimed(totalClaimed-coverage_table1a_mother+val); 
          }
          console.log("Current = " + val);
        }
        break;

      default:
        break;
    }
    //}
  }

  const ageCount = (dob) => {
    var date1 = new Date();
    //var  dob= document.getElementById("dob").value;
    var date2 = new Date(dob);
    var pattern = /^\d{1,2}\/\d{1,2}\/\d{4}$/; //Regex to validate date format (dd/mm/yyyy)
    if (pattern.test(dob)) {
      var y1 = date1.getFullYear(); //getting current year
      var y2 = date2.getFullYear(); //getting dob year
      var age = y1 - y2;           //calculating age 
      document.write("Age : " + age);
      return true;
    } else {
      alert("Invalid date format. Please Input in (dd/mm/yyyy) format!");
      return false;
    }
  }

  const handleInputChangeSum = (event, index) => {
    const newValue = event.target.value;
    setInputValues(prevValues => {
      const newValues = [...prevValues];
      newValues[index] = newValue;
      return newValues;
    });
  };

  function validateMaxValue(inputValue, maxValue) {
    if (inputValue > maxValue) {
      alert(`Value cannot exceed ${maxValue}`);
      return false;
    }
    return true;
  }


  function totalClaimed1() {
    const total = coverage_table1 + coverage_table1_dep_child1 + coverage_table1_dep_child2 + coverage_table1_dep_child3 + coverage_table1_spouse +
      coverage_table1a + coverage_table1a_dep_child1 + coverage_table1a_dep_child2 + coverage_table1a_dep_child3 + coverage_table1a_father
      + coverage_table1a_mother + coverage_table1a_spouse
      + coverage_table2 + coverage_table2_dep_child1 + coverage_table2_dep_child2 + coverage_table2_dep_child3 + coverage_table2_spouse +
      coverage_table3 + coverage_table3_spouse;
    return total;
  }


  function alertMaxAllotted(values) {
    if (!Array.isArray(values)) {
      throw new TypeError('Expected an array of numbers');
    }

    // Get the sum of the numbers
    const total = values.reduce((sum, value) => sum + parseInt(value), 0);
    //console.log("TOTALLLLLL==="+parseInt(total))
    // Alert the maximum allotted value based on the total
    if (total > 100) {
      alert('Maximum allotted is 100');
    }
    else {

    }
  }
  /*
  function alertMaxAllotted(inputs) {
    // Convert inputs to an array of numbers
    const numbers = inputs.map(input => parseFloat(input.value)).filter(value => !isNaN(value));
    
    // Get the sum of the numbers
    const total = numbers.reduce((sum, value) => sum + value, 0);
    
    // Alert the maximum allotted value based on the total
    if (total <= 100) {
      alert('Maximum allotted is 100');
    } else if (total <= 200) {
      alert('Maximum allotted is 200');
    } else {
      alert('Maximum allotted is 300');
    }
  }*/

  const calculate_age = (dob) => {
    if (dob == null || dob == "") {
      return 0;
    }
    const date = parse(dob, "dd-MM-yyyy", new Date())
    const age = differenceInYears(new Date(), date)
    return age
  }

  const calculate_premium = (props) => {
    const t1 = coverage_table1;
    const t2 = coverage_table1_spouse;
    const t3 = coverage_table1_dep_child1;
    const t4 = coverage_table1_dep_child2;
    const t5 = coverage_table1_dep_child3;
    const t6 = coverage_table1a;
    const t7 = coverage_table1a_spouse;
    const t8 = coverage_table1a_dep_child1;
    const t9 = coverage_table1a_dep_child2;
    const t10 = coverage_table1a_dep_child3;
    const t11 = coverage_table1a_father;
    const t12 = coverage_table1a_mother;
    const t13 = coverage_table2;
    const t14 = coverage_table2_spouse;
    const t15 = coverage_table2_dep_child1;
    const t16 = coverage_table2_dep_child2;
    const t17 = coverage_table2_dep_child3;
    const t18 = coverage_table3;
    const t19 = coverage_table3_spouse;
    console.log(t1);
    /*const t2 = document.getElementById("spouseTable1").value?document.getElementById("spouseTable1").value:0;
    const t3 = document.getElementById("child1Table1").value?document.getElementById("child1Table1").value:0
    const t4 = document.getElementById("child2Table1").value?document.getElementById("child2Table1").value:0
    const t5 = document.getElementById("child3Table1").value?document.getElementById("child3Table1").value:0
    const t6 = document.getElementById("coverage_table1a").value?document.getElementById("coverage_table1a").value:0
    const t7 = document.getElementById("spouseTable1a").value?document.getElementById("spouseTable1a").value:0
    const t8 = document.getElementById("child1Table1a").value?document.getElementById("child1Table1a").value:0
    const t9 = document.getElementById("child2Table1a").value?document.getElementById("child2Table1a").value:0
    const t10 = document.getElementById("child3Table1a").value?document.getElementById("child3Table1a").value:0
    const t11 = document.getElementById("parent1Table1a").value?document.getElementById("parent1Table1a").value:0
    const t12 = document.getElementById("parent2Table1a").value?document.getElementById("parent2Table1a").value:0
    const t13 = document.getElementById("coverage_table2").value?document.getElementById("coverage_table2").value:0
    const t14 = document.getElementById("spouseTable2").value?document.getElementById("spouseTable2").value:0
    const t15 = document.getElementById("child1Table2").value?document.getElementById("child1Table2").value:0
    const t16 = document.getElementById("child2Table2").value?document.getElementById("child2Table2").value:0
    const t17 = document.getElementById("child3Table2").value?document.getElementById("child3Table2").value:0
    const t18 = document.getElementById("coverage_table3").value?document.getElementById("coverage_table3").value:0
    const t19 = document.getElementById("spouseTable3").value?document.getElementById("spouseTable3").value:0
    */
    setPremium((t1 + t2 + t3 + t4 + t5) * configTable1_Amount + (t6 + t7 + t8 + t9 + t10 + t11 + t12) * configTable1a_Amount + (t13 + t14 + t15 + t16 + t17) * configTable2_Amount + (t18 + t19) * configTable3_Amount);
    console.log("T1 == " + premium);
    //props.useCallback;
    //return premium;
  };

  const printGai = (e) => {
    if (emp_code == '' || emp_code == null) {
      alert("For Employees Only");
      return;
    }
    else {
      var reportParam = "empCode:S:" + emp_code;
      var report = "gai.jasper";
      var variables = {
        REPORT_PATH: report,
        OUTPUT_FILE: "GAI.pdf",
        PARAMETERS: reportParam
      };
      //var qrString="User_Id="+userId+"&sessionId="+userId+"&"+"REPORT_PATH="+variables.REPORT_PATH+"&"+"OUTPUT_FILE="+variables.OUTPUT_FILE+"&"+"PARAMETERS="+variables.PARAMETERS;
      var qrString = "User_Id=" + props.userId + "&" + "REPORT_PATH=" + variables.REPORT_PATH + "&" + "OUTPUT_FILE=" + variables.OUTPUT_FILE + "&" + "PARAMETERS=" + variables.PARAMETERS;
      console.log("QRRRRRRRR  " + qrString);
      const requestOptions = {
        method: 'POST',
        data: variables
      };
      console.log(JSON.stringify(variables))
      window.open(
        configData.RPT_URL + '?' + qrString,
        '_blank' // <- This is what makes it open in a new window.
      );
    }
    useCallback(userId);
  }

  const handleAlert = () => {
    const result = window.confirm("Are you sure you want to do this?");
    if (result) {
      // User clicked "OK"
      // Do something here
    } else {
      // User clicked "Cancel"
      // Do something else here
    }
  };

  let handleSubmit = async (e) => {
    e.preventDefault();
    //console.log("Save 1 "+totalClaimed);
    var totLimit = noMonthsCounted * grossSalaryPerMonth;

    setIsValid(true);
    //console.log(spouse_dob);
    try {
      let gai = {
        gai_id: gai_id,
        fin_year: configFinYear,
        emp_code: emp_code,
        emp_name: emp_name,
        ext_no: ext_no,
        mobile: mobile,
        dob: dob,
        designation_grade: designation_grade,
        dept_section: dept_section,
        grossSalaryPerMonth: grossSalaryPerMonth,
        coverage_table1: coverage_table1,
        coverage_table1a: coverage_table1a,
        coverage_table2: coverage_table2,
        coverage_table3: coverage_table3,
        spouse_name: spouse_name,
        spouse_dob: spouse_dob,
        spouse_employed: spouse_employed,
        spouse_office: spouse_office,
        spouse_salary: spouse_salary,
        child1_name: child1_name,
        child1_dob: child1_dob,
        child2_name: child2_name,
        child2_dob: child2_dob,
        child3_name: child3_name,
        child3_dob: child3_dob,
        parent1_name: parent1_name,
        parent1_dob: parent1_dob,
        parent2_name: parent2_name,
        parent2_dob: parent2_dob,
        coverage_table1_spouse: coverage_table1_spouse,
        coverage_table1_dep_child1: coverage_table1_dep_child1,
        coverage_table1_dep_child2: coverage_table1_dep_child2,
        coverage_table1_dep_child3: coverage_table1_dep_child3,
        coverage_table1a_spouse: coverage_table1a_spouse,
        coverage_table1a_dep_child1: coverage_table1a_dep_child1,
        coverage_table1a_dep_child2: coverage_table1a_dep_child2,
        coverage_table1a_dep_child3: coverage_table1a_dep_child3,
        coverage_table2_spouse: coverage_table2_spouse,
        coverage_table2_dep_child1: coverage_table2_dep_child1,
        coverage_table2_dep_child2: coverage_table2_dep_child2,
        coverage_table2_dep_child3: coverage_table2_dep_child3,
        coverage_table3_spouse: coverage_table3_spouse,
        coverage_table1a_father: coverage_table1a_father,
        coverage_table1a_mother: coverage_table1a_mother,
        self_nominee: self_nominee,
        self_nominee_relation: self_nominee_relation,
        spouse_nominee: spouse_nominee,
        spouse_nominee_relation: spouse_nominee_relation,
        children_nominee: children_nominee,
        children_nominee_relation: children_nominee_relation,
        parents_nominee: parents_nominee,
        parents_nominee_relation: parents_nominee_relation,
        sscp_nominee: sscp_nominee,
        sscp_nominee_relation: sscp_nominee_relation,
        signed_date: signed_date,
        witness_name: witness_name,
        settlement: settlement,
        status: status,
        settled_amount: settled_amount,
        salary_months: noMonthsCounted,
        monthly_gross: grossSalaryPerMonth
      };
      console.log(update + "Status save" + JSON.stringify(gai));

      if (update === true) {
        //console.log("Save 5 ");
        //console.log("Status update!!!!!!!!!!"+update);
        let res = await fetch(
          //console.log("update====="+gai.gai_id)
          DataService.updateGai(gai_id, gai).then(res => {
            //console.log("*****************"+JSON.stringify(res.data)+"*******************");
            alert('Successfully Updated Record');
          }))
      }
      else {
        setShow(true);
        let res = await fetch(
          DataService.saveGai(gai).then(res => {
            //console.log("*****************"+JSON.stringify(res.data)+"*******************");
            document.getElementById("printBtn").disabled = false;
            setUpdate(true);
            alert('Successfully Saved Record')
          }))
      }

    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div class="form-container">
      <form>
        <div class="form-sections">
          <div class="form-section">
            <h3>Employee Information</h3>
            <div class="form-row">

              <div class="form-col">
                <label htmlFor="name">Name (in Capital Letters) :  </label>
                <input className="bgdisabledColor"
                  type="text"
                  data-tip data-for="nameTip"
                  id="name"
                  maxLength="100"
                  required={true}
                  value={emp_name}
                  disabled={true}
                  //onChange={onChangeName}
                  name="name"
                />
              </div>

              <div class="form-col">
                <label htmlFor="staffNo">Staff No (mandatory)       :  </label>
                <input className="bgdisabledColor"
                  type="text"
                  data-tip data-for="staffNoTip"
                  id="staffNo"
                  maxLength="10"
                  readOnly={true}
                  required={true}
                  value={emp_code}
                  disabled={true}
                  //onChange=""
                  name="staffNo"
                />
              </div>

              <div class="form-col">
                <label htmlFor="extNo">Extension No :  </label>
                <input
                  type="text"
                  data-tip data-for="extNoTip"
                  className="bgdisabledColor"
                  id="extNo"
                  maxLength="100"
                  required={true}
                  value={ext_no}
                  disabled={true}
                  //onChange={onChangeExtNo}
                  name="extNo"
                />
              </div>
              <div class="form-col">
                <label htmlFor="mobile">Mobile No :  </label>
                <input
                  type="text"
                  data-tip data-for="mobileTip"
                  className="bgdisabledColor"
                  id="mobileNo"
                  maxLength="10"
                  required={true}
                  value={mobile}
                  disabled={true}
                  //onChange={onChangeMobile}
                  name="mobileNo"
                />
              </div>
              <div class="form-col">
                <label htmlFor="dob">Date of Birth :  </label>
                <DatePicker
                  name='dob'
                  type='date'
                  id="dob"
                  className="input-field bgdisabledColor"
                  dateFormat="dd-MM-yyyy"
                  maxDate={new Date()}
                  value={dob}
                  disabled={true}

                //onChange={onChangeDob}
                />
              </div>
              <div class="form-col">
                <label htmlFor="designation">Designation / Grade	 :  </label>
                <input
                  type="text"
                  data-tip data-for="designationTip"
                  className="bgdisabledColor"
                  id="designation"
                  maxLength="100"
                  required={true}
                  value={designation_grade}
                  disabled={true}
                  //onChange={onChangeDesignation}
                  name="designation"
                />
              </div>
              <div class="form-col">
                <label htmlFor="dept">Department / Section :  </label>
                <input
                  name='dept'
                  type='text'
                  required={true}
                  id="dept"
                  className="bgdisabledColor"
                  value={dept_section}
                  disabled={true}
                //onChange={onChangeDeptSection}
                />
              </div>
              <div class="form-col">
                <label className="parent" htmlFor="grossSalary">Monthly Gross Salary (Basic + DA + TA + HRA) or Consolidated Amount	 : {grossSalaryPerMonth}  </label>
                <label className="parent" htmlFor="eligibleAmt">Max Coverage (All tables together for employee) :</label> <label className="child">{grossSalaryPerMonth * noMonthsCounted}</label>
              </div>
              {/*<div class="form-col">
                  <table>
                        <tr>
                          <td>
                            <Button className="col-md-1" onClick={autoSetValues}>Set Auto 1</Button> 
                          </td>
                          <td>
                            <Button className="col-md-1" onClick={autoSetValues}>Set Auto 2</Button>
                           </td>
                           <td>
                            <Button className="col-md-1" onClick={autoSetValues}>Set Auto 2</Button>
                          </td>                        
                        </tr>                
                  </table>
                </div>
            */}
              <div class="form-col">
                <label htmlFor="coverage_table1">Coverage requested (For member)  1) Death only           :  Table I    (Rs) : </label>
                <input
                  name='coverage_table1'
                  type='text'
                  required={true}
                  id="coverage_table1"
                  className="form-control "
                  value={coverage_table1}
                  pattern="[0-9]*"
                  onChange={handleInputChange}
                  title="Amount in Rupees"
                />
                <label className="lakhsLabel">{coverage_table1 / 100000 + "  Lakhs"}</label>

              </div>

              <div class="form-col">
                <label htmlFor="coverage_table1a">Coverage requested (For member)  2) Death/ PTD          :  Table I (a)(Rs) : </label>
                <input
                  name='coverage_table1a'
                  type='text'
                  required={true}
                  id="coverage_table1a"
                  className="form-control"
                  value={coverage_table1a}
                  onChange={handleInputChange}
                  title="Amount in Rupees"
                //onChange={onChangeCoverageTable1a}
                />
                <label className="lakhsLabel">{coverage_table1a / 100000 + "  Lakhs"}</label>
              </div>

              <div class="form-col">
                <label htmlFor="coverage_table2">Coverage requested (For member)  3) Death/ PTD / PPD    :  Table II (Rs)  : </label>
                <input
                  name='coverage_table2'
                  type='text'
                  required={true}
                  id="coverage_table2"
                  className="form-control"
                  value={coverage_table2}
                  onChange={handleInputChange}
                  title="Amount in Rupees"
                //onChange={onChangeCoverageTable2}
                />
                <label className="lakhsLabel">{coverage_table2 / 100000 + "  Lakhs"}</label>
              </div>
              <div class="form-col">
                <label htmlFor="coverage_table3">Coverage requested (For member)  4) Death/PTD/PPD / TTD  : Table III (Rs) : </label>
                <input
                  name='coverage_table3'
                  type='text'
                  required={true}
                  id="coverage_table3"
                  className="form-control"
                  value={coverage_table3}
                  onChange={handleInputChange}
                  title="Amount in Rupees"
                //onChange={onChangeCoverageTable3}
                />
                <label className="lakhsLabel">{coverage_table3 / 100000 + "  Lakhs"}</label><label htmlFor="coverage_table3">(Max. sum insured under Table III is limited to Rs. 7.5 lacs.)</label>
              </div>
            </div>
          </div>
          <div class="form-section">
            <h3>Details of Spouse</h3>
            <div class="form-row">
              <div class="form-col">
                <label htmlFor="spouseName">a)  Name  :  </label>
                <input
                  type="text"
                  data-tip data-for="spouseNameTip"
                  className="bgdisabledColor"
                  id="spouseName"
                  maxLength="100"
                  required={true}
                  value={spouse_name}
                  //onChange={onChangeSpouseName}
                  name="spouseName"
                  disabled={true}
                />
              </div>
              <div class="form-col">
                <label htmlFor="spouseDob">b)  Date of Birth :  </label>
                <DatePicker
                  name='spouseDob'
                  type='date'
                  id="spouseDob"
                  className="input-field bgdisabledColor"
                  dateFormat="dd-MM-yyyy"
                  maxDate={new Date()}
                  value={spouse_dob}
                  disabled={true}
                //onChange={onChangeSpouseDob}
                />
              </div>
              <div class="form-col">
                <label className="labelOnly inline" htmlFor="isEmployed">c)	Is employed (Yes / No)     :  </label>
                <select
                  className="form-control "
                  id="isEmployed"
                  name="isEmployed"
                  value={spouse_employed}
                  onChange={onChangeSpouseEmployed}>
                  <option value="Select" >Select</option>
                  {
                    isEmployed.map((e) => (<option value={e.value} title={e.value}>{e.value}</option>))
                  }
                </select>
              </div>
              <div class="form-col">
                <label htmlFor="spouseOrganisation">d)	Name of office / organization    :  </label>
                <input
                  type="text"
                  data-tip data-for="spouseOrganisationTip"
                  className="form-control"
                  id="spouseOrganisation"
                  maxLength="100"
                  value={spouse_office}
                  onChange={onChangeSpouse_Office}
                  name="spouseOrganisation"
                  disabled={true}
                />
              </div>
              <div class="form-col">
                <label htmlFor="spouseSalary">e)	Monthly Gross Salary                :</label>
                <input
                  type="text"
                  data-tip data-for="spouseSalaryTip"
                  className="form-control"
                  id="spouseSalary"
                  maxLength="100"
                  value={spouse_salary}
                  onChange={onChangeSpouseSalary}
                  name="spouseSalary"
                  disabled={true}
                />
              </div>
            </div>
          </div>
          <div class="form-section">
            <h3>Details of Dependent children: (should be unemployed)</h3>
            <div class="form-row">
              <div class="form-col">
                <label htmlFor="childName1">Child 1 Name  :  </label>
                <input
                  type="text"
                  data-tip data-for="childName1Tip"
                  className="bgdisabledColor"
                  id="childName1"
                  maxLength="100"
                  required={false}
                  value={child1_name}
                  //onChange={onChangeChild1Name}
                  name="childName1"
                  disabled={true}
                />
              </div>
              <div class="form-col">
                <label htmlFor="child1Dob">Child 1 Date of Birth :  </label>
                <DatePicker
                  name='child1Dob'
                  type='date'
                  id="child1Dob"
                  className="input-field bgdisabledColor"
                  dateFormat="dd-MM-yyyy"
                  maxDate={new Date()}
                  value={child1_dob}
                  disabled={true}
                //onChange={onChangeChild1Dob}
                />
              </div>
              <div class="form-col">
                <label className="labelOnly" htmlFor="child1Age">Age : {calculate_age(child1_dob)}</label>
              </div>
              <div class="form-col">
                <label htmlFor="childName2">Child 2 Name  :  </label>
                <input
                  type="text"
                  data-tip data-for="childName2Tip"
                  className="bgdisabledColor"
                  id="childName2"
                  maxLength="100"
                  required={false}
                  value={child2_name}
                  disabled={true}
                  //onChange={onChangeChild2Name}
                  name="childName2"
                />
              </div>
              <div class="form-col">
                <label htmlFor="child2Dob">Child 2 Date of Birth :  </label>
                <DatePicker
                  name='child2Dob'
                  type='date'
                  id="child2Dob"
                  className="input-field bgdisabledColor"
                  dateFormat="dd-MM-yyyy"
                  maxDate={new Date()}
                  value={child2_dob}
                  disabled={true}
                //onChange={onChangeChild2Dob}
                />
              </div>
              <div class="form-col">
                <label className="labelOnly" htmlFor="child2Age">Age : {calculate_age(child2_dob)}</label>
              </div>
              <div class="form-col">
                <label htmlFor="childName3">Child 3 Name  :  </label>
                <input
                  type="text"
                  data-tip data-for="childName3Tip"
                  className="bgdisabledColor"
                  id="childName3"
                  maxLength="100"
                  value={child3_name}
                  disabled={true}
                  //onChange={onChangeChild3Name}
                  name="childName3"
                />
              </div>
              <div class="form-col">
                <label htmlFor="child3Dob">Child 3 Date of Birth :  </label>
                <DatePicker
                  name='child3Dob'
                  type='date'
                  id="child3Dob"
                  className="input-field bgdisabledColor"
                  dateFormat="dd-MM-yyyy"
                  maxDate={new Date()}
                  value={child3_dob}
                  disabled={true}
                // onChange={onChangeChild3Dob}
                />
              </div>
              <div class="form-col">
                <label className="labelOnly" htmlFor="child3Age">Age : {calculate_age(child3_dob)}</label>
              </div>
            </div>
          </div>



          <div class="form-section">
            <h3>Details of Dependent Parents (Table 1(a))</h3>
            <div class="form-row">
              <div class="form-col">
                <label htmlFor="parentName1">Parent 1 Name  :  </label>
                <input
                  type="text"
                  data-tip data-for="parentName1Tip"
                  className="bgdisabledColor"
                  id="parentName1"
                  maxLength="100"
                  required={false}
                  value={parent1_name}
                  //onChange={onChangeParemt1Name}
                  disabled={true}
                  name="parentName1"
                />
              </div>
              <div class="form-col">
                <label htmlFor="parent1Dob">Parent 1 Date of Birth :  </label>
                <DatePicker
                  name='parent1Dob'
                  type='date'
                  id="parent1Dob"
                  className="input-field bgdisabledColor"
                  dateFormat="dd-MM-yyyy"
                  maxDate={new Date()}
                  value={parent1_dob}
                  disabled={true}
                //onChange={onChangeParent1Dob}
                />
              </div>
              <div class="form-col">
                <label className="labelOnly" htmlFor="parent1Age">Age : {calculate_age(parent1_dob)}</label>
              </div>
              <div class="form-col">
                <label htmlFor="parentName2">Parent 2 Name  :  </label>
                <input
                  type="text"
                  data-tip data-for="parentName2Tip"
                  className="bgdisabledColor"
                  id="parentName2"
                  maxLength="100"
                  required={false}
                  value={parent2_name}
                  //onChange={onChangeParent2Name}
                  disabled={true}
                  name="parentName2"
                />
              </div>
              <div class="form-col">
                <label htmlFor="parent2Dob">Parent 2 Date of Birth :  </label>
                <DatePicker
                  name='parent2Dob'
                  type='date'
                  id="parent2Dob"
                  className="input-field bgdisabledColor"
                  dateFormat="dd-MM-yyyy"
                  maxDate={new Date()}
                  value={parent2_dob}
                  disabled={true}
                //onChange={onChangeParent2Dob}
                />
              </div>
              <div class="form-col">
                <label className="labelOnly" htmlFor="parent2Age">Age : {calculate_age(parent2_dob)}</label>

              </div>
            </div>
          </div>


          <div class="form-section">
            <h3>Coverage requested for Spouse and Dependent Children : Table I</h3>
            <div class="form-row">
              <div class="form-col">
                <label htmlFor="spouseTable1">Spouse  :  </label>
                <input
                  type="text"
                  data-tip data-for="spouseTable1Tip"
                  className="form-control"
                  id="spouseTable1"
                  maxLength="100"
                  required={false}
                  value={coverage_table1_spouse}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1Spouse}
                  name="spouseTable1"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1_spouse / 100000 + "  Lakhs"}</label><label htmlFor="spouseTable1Deta">For Unemployed Spouse (Maximum of 50% of Employee Contribution)  </label>
                <Tooltip id="spouseTable1Tip" effect="solid">Amount in Rupees</Tooltip>
              </div>
              <div class="form-col">
                <label htmlFor="child1Table1">Child 1  :  </label>
                <input
                  type="text"
                  data-tip data-for="child1Table1Tip"
                  className="form-control"
                  id="child1Table1"
                  maxLength="100"
                  required={false}
                  value={coverage_table1_dep_child1}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1DepChild1}
                  name="child1Table1"
                  disabled={true}
                  title="Amount in Rupees"
                />
                <label className="lakhsLabel">{coverage_table1_dep_child1 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child1Table1Deta">(Maximum of 25% of Employee Contribution) </label>
              </div>
              <div class="form-col">
                <label htmlFor="child2Table1">Child 2  :  </label>
                <input
                  type="text"
                  data-tip data-for="child2Table1Tip"
                  className="form-control"
                  id="child2Table1"
                  maxLength="100"
                  required={false}
                  value={coverage_table1_dep_child2}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1DepChild2}
                  name="child2Table1"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1_dep_child2 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child2Table1Deta">(Maximum of 25% of Employee Contribution) </label>
              </div>
              <div class="form-col">
                <label htmlFor="child3Table1">Child 3  :  </label>
                <input
                  type="text"
                  data-tip data-for="child3Table1Tip"
                  className="form-control"
                  id="child3Table1"
                  maxLength="100"
                  required={false}
                  value={coverage_table1_dep_child3}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1DepChild3}
                  name="child3Table1"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1_dep_child3 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child1Table1Deta">(Maximum of 25% of Employee Contribution) </label>
              </div>

            </div>
          </div>


          <div class="form-section">
            <h3>Coverage requested for spouse and Dependent Children : Table I (a)</h3>
            <div class="form-row">
              <div class="form-col">
                <label htmlFor="spouseTable1a">Spouse  :  </label>
                <input
                  type="text"
                  data-tip data-for="spouseTable1aTip"
                  className="form-control"
                  id="spouseTable1a"
                  maxLength="100"
                  required={false}
                  value={coverage_table1a_spouse}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1aSpouse}
                  name="spouseTable1a"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1a_spouse / 100000 + "  Lakhs"}</label>
                <label htmlFor="spouseTable1aDeta"> </label>
              </div>
              <div class="form-col">
                <label htmlFor="child1Table1a">Child 1  :  </label>
                <input
                  type="text"
                  data-tip data-for="child1Table1aTip"
                  className="form-control"
                  id="child1Table1a"
                  maxLength="100"
                  required={false}
                  value={coverage_table1a_dep_child1}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1aDepChild1}
                  name="child1Table1a"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1a_dep_child1 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child1Table1aDeta"></label>
              </div>
              <div class="form-col">
                <label htmlFor="child2Table1a">Child 2  :  </label>
                <input
                  type="text"
                  data-tip data-for="child2Table1aTip"
                  className="form-control"
                  id="child2Table1a"
                  maxLength="100"
                  required={false}
                  value={coverage_table1a_dep_child2}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1aDepChild2}
                  name="child2Table1a"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1a_dep_child2 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child2Table1aDeta"> </label>
              </div>
              <div class="form-col">
                <label htmlFor="child3Table1a">Child 3  :  </label>
                <input
                  type="text"
                  data-tip data-for="child3Table1aTip"
                  className="form-control"
                  id="child3Table1a"
                  maxLength="100"
                  required={false}
                  value={coverage_table1a_dep_child3}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1aDepChild3}
                  name="child3Table1a"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1a_dep_child3 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child1Table1aDeta"></label>
              </div>

            </div>
          </div>


          <div class="form-section">
            <h3>Coverage requested for spouse and Dependent Children : Table II</h3>
            <div class="form-row">
              <div class="form-col">
                <label htmlFor="spouseTable2">Spouse  :  </label>
                <input
                  type="text"
                  data-tip data-for="spouseTable2Tip"
                  className="form-control"
                  id="spouseTable2"
                  maxLength="100"
                  required={false}
                  value={coverage_table2_spouse}
                  onChange={handleInputChange}
                  //onChange={onChangeTable2Spouse}
                  name="spouseTable2"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table2_spouse / 100000 + "  Lakhs"}</label>
                <label htmlFor="spouseTable2Deta"> </label>
              </div>
              <div class="form-col">
                <label htmlFor="child1Table2">Child 1  :  </label>
                <input
                  type="text"
                  data-tip data-for="child1Table2Tip"
                  className="form-control"
                  id="child1Table2"
                  maxLength="100"
                  required={false}
                  value={coverage_table2_dep_child1}
                  onChange={handleInputChange}
                  //onChange={onChangeTable2DepChild1}
                  name="child1Table2"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table2_dep_child1 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child1Table2Deta"></label>
              </div>
              <div class="form-col">
                <label htmlFor="child2Table2">Child 2  :  </label>
                <input
                  type="text"
                  data-tip data-for="child2Table2Tip"
                  className="form-control"
                  id="child2Table2"
                  maxLength="100"
                  required={false}
                  value={coverage_table2_dep_child2}
                  onChange={handleInputChange}
                  //onChange={onChangeTable2DepChild2}
                  name="child2Table2"
                  disabled={true}
                  title="Amount in Rupees"
                />
                <label className="lakhsLabel">{coverage_table2_dep_child2 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child2Table2Deta"> </label>
              </div>
              <div class="form-col">
                <label htmlFor="child3Table2">Child 3  :  </label>
                <input
                  type="text"
                  data-tip data-for="child3Table2Tip"
                  className="form-control"
                  id="child3Table2"
                  maxLength="100"
                  required={false}
                  value={coverage_table2_dep_child3}
                  onChange={handleInputChange}
                  //onChange={onChangeTable2DepChild3}
                  name="child3Table2"
                  disabled={true}
                  title="Amount in Rupees"
                />
                <label className="lakhsLabel">{coverage_table2_dep_child3 / 100000 + "  Lakhs"}</label>
                <label htmlFor="child1Table2Deta"></label>
              </div>

            </div>
          </div>

          <div class="form-section">
            <h3>Coverage requested for spouse : Table III</h3>
            <div class="form-row">
              <div class="form-col-6">
                <label htmlFor="spouseTable3">Spouse  :  </label>
                <input
                  type="text"
                  data-tip data-for="spouseTable3Tip"
                  className="form-control"
                  id="spouseTable3"
                  maxLength="100"
                  required={false}
                  title="Amount in Rupees"
                  value={coverage_table3_spouse}
                  onChange={handleInputChange}
                  //onChange={onChangeTable3Spouse}
                  disabled={true}
                  name="spouseTable3"
                />
                <label className="lakhsLabel">{coverage_table3_spouse / 100000 + "  Lakhs"}</label>
                <label htmlFor="spouseTable3Deta1"> (If employed, max sum insured limited Rs.7.5 lakhs)(Not applicable for Unemployed/Self employed)</label>

              </div>

            </div>
          </div>

          <div class="form-section">
            <h3>Coverage requested for Dependent Parents : Table I (a)</h3>
            <div class="form-row">

              <div class="form-col">
                <label htmlFor="parent1Table1a">Father  :  </label>
                <input
                  type="text"
                  data-tip data-for="parent1Table1aTip"
                  className="form-control"
                  id="parent1Table1a"
                  maxLength="100"
                  required={false}
                  value={coverage_table1a_father}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1aFather}
                  name="parent1Table1a"
                  disabled={true}
                  title="Amount in Rupees"
                />
                <label className="lakhsLabel">{coverage_table1a_father / 100000 + "  Lakhs"}</label>
              </div>


              <div class="form-col">
                <label htmlFor="parent2Table1a">Mother  :  </label>
                <input
                  type="text"
                  data-tip data-for="parent2Table1aTip"
                  className="form-control"
                  id="parent2Table1a"
                  maxLength="100"
                  required={false}
                  value={coverage_table1a_mother}
                  onChange={handleInputChange}
                  //onChange={onChangeTable1aMother}
                  name="parent2Table1a"
                  title="Amount in Rupees"
                  disabled={true}
                />
                <label className="lakhsLabel">{coverage_table1a_mother / 100000 + "  Lakhs"}</label>
                <label htmlFor="parent1Table1aLbl">(Maximum sum insured limited to Rs.5 lakhs per parent)</label>
              </div>

            </div>
          </div>


          <div class="form-section">
            <h3>Nominee Details</h3>
            <div class="form-row">
              <div class="widthpercent">
                <label htmlFor="self_nominee">In the event of death of Self  :  Name</label>
                <input
                  type="text"
                  data-tip data-for="self_nomineeTip"
                  className="form-control"
                  id="self_nominee"
                  maxLength="100"
                  required={false}
                  value={self_nominee}
                  onChange={onChangeSelfNominee}
                  name="self_nominee"
                />


              </div>

              <div class="widthpercent">
                <label htmlFor="self_nominee_relation">Nominee’s relationship with staff member</label>
                <select
                  className="form-control"
                  id="self_nomineeRelation"
                  name="self_nomineeRelation"
                  value={self_nominee_relation}
                  onChange={onChangeSelfNomineeRelation}>
                  <option value="Select" >Select</option>
                  {
                    relationList.map((e) => (<option value={e.value} title={e.value}>{e.value}</option>))
                  }
                </select>
                <label htmlFor="self_nomineeRelationLbl"></label>
              </div>
              <div class="widthpercent">
                <label htmlFor="spouse_nominee">In the event of death of Spouse  :  Name</label>
                <input
                  type="text"
                  data-tip data-for="spouse_nomineeTip"
                  className="form-control"
                  id="spouse_nominee"
                  maxLength="100"
                  required={false}
                  value={spouse_nominee}
                  onChange={onChangeSpouseNominee}
                  name="spouse_nominee"
                />
              </div>
              <div class="widthpercent">
                <label htmlFor="spouse_nominee_relation">Nominee’s relationship with staff member</label>
                <select
                  className="form-control"
                  id="spouse_nomineeRelation"
                  name="spouse_nomineeRelation"
                  value={spouse_nominee_relation}
                  onChange={onChangeSpouseNomineeRelation}>
                  <option value="Select" >Select</option>
                  {
                    relationList.map((e) => (<option value={e.value} title={e.value}>{e.value}</option>))
                  }
                </select>
                <label htmlFor="spouse_nomineeRelationLbl"></label>
              </div>
              <div class="widthpercent">
                <label htmlFor="children_nominee">In the event of death of Children  :  Name</label>
                <input
                  type="text"
                  data-tip data-for="children_nomineeTip"
                  className="form-control"
                  id="children_nominee"
                  maxLength="100"
                  required={false}
                  value={children_nominee}
                  onChange={onChangeChildNominee}
                  name="children_nominee"
                />
              </div>
              <div class="widthpercent">
                <label htmlFor="children_nominee_relation">Nominee’s relationship with staff member</label>
                <select
                  className="form-control"
                  id="children_nomineeRelation"
                  name="children_nomineeRelation"
                  value={children_nominee_relation}
                  onChange={onChangeChildNomineeRelation}>
                  <option value="Select" >Select</option>
                  {
                    relationList.map((e) => (<option value={e.value} title={e.value}>{e.value}</option>))
                  }
                </select>
                <label htmlFor="children_nomineeRelationLbl"></label>
              </div>
              <div class="widthpercent">
                <label htmlFor="parents_nominee">In the event of death of Parents  :  Name</label>
                <input
                  type="text"
                  data-tip data-for="parents_nomineeTip"
                  className="form-control"
                  id="parents_nominee"
                  maxLength="100"
                  required={false}
                  value={parents_nominee}
                  onChange={onChangeParentNominee}
                  name="parents_nominee"
                />
              </div>
              <div class="widthpercent">
                <label htmlFor="parents_nominee_relation">Nominee’s relationship with staff member</label>
                <select
                  className="form-control"
                  id="parents_nomineeRelation"
                  name="parents_nomineeRelation"
                  value={parents_nominee_relation}
                  onChange={onChangeParentNomineeRelation}>
                  <option value="Select" >Select</option>
                  {
                    relationList.map((e) => (<option value={e.value} title={e.value}>{e.value}</option>))
                  }
                </select>
                <label htmlFor="self_nomineeRelationLbl"></label>
              </div>
              <div class="widthpercent">
                <label htmlFor="sscp_nominee">In the event of death of Self, Spouse, Children & Parents  :  Name</label>
                <input
                  type="text"
                  data-tip data-for="sscp_nomineeTip"
                  className="form-control"
                  id="sscp_nominee"
                  maxLength="100"
                  required={false}
                  value={sscp_nominee}
                  onChange={onChangeSscpNominee}
                  name="sscp_nominee"
                />
              </div>
              <div class="widthpercent">
                <label htmlFor="sscp_nominee_relation">Nominee’s relationship with staff member</label>

                <select
                  className="form-control"
                  id="sscp_nomineeRelation"
                  name="sscp_nomineeRelation"
                  value={sscp_nominee_relation}
                  onChange={onChangeSscpNomineeRelation}>
                  <option value="Select" >Select</option>
                  {
                    relationList.map((e) => (<option value={e.value} title={e.value}>{e.value}</option>))
                  }
                </select>
                <label htmlFor="self_nomineeRelationLbl"></label>
              </div>
              <div class="widthpercent">
                <label htmlFor="filed_date">Date</label>
                <DatePicker
                  name='filed_date'
                  type='date'
                  id="filed_date"
                  className="form-control"
                  dateFormat="dd/MM/yyyy"
                  maxDate={new Date()}
                  value={signed_date}
                  onChange={onChangeSignedDate}
                />
                {/*setSigned_Date(dateFormat(gaiData1.signed_date, "dd-mm-yyyy"));*/}

              </div>
              <div class="widthpercent">
                <label htmlFor="witness_name">Witness Name</label>
                <input
                  type="text"
                  data-tip data-for="witness_nameTip"
                  className="form-control"
                  id="witness_name"
                  maxLength="100"
                  //required={false}
                  value={witness_name}
                  onChange={onChangeWitness}
                  name="witness_name"
                />
                <label htmlFor="witness_nameLbl"></label>
              </div>
            </div>
          </div>
          <div class="form-row">
            <div class="widthpercent">
              <label className="parent" htmlFor="totalClaim">Maximum Covered in Rs	 :  </label> <label id="sumAssuredLbl" className="child">{parseInt(coverage_table1) + parseInt(coverage_table1a) + parseInt(coverage_table2) + parseInt(coverage_table3) + parseInt(coverage_table1_spouse) +
                parseInt(coverage_table1_dep_child1) + parseInt(coverage_table1_dep_child2) + parseInt(coverage_table1_dep_child3) + parseInt(coverage_table1a_spouse) + parseInt(coverage_table1a_dep_child1) + parseInt(coverage_table1a_dep_child2) + parseInt(coverage_table1a_dep_child3) +
                parseInt(coverage_table2_spouse) + parseInt(coverage_table2_dep_child1) + parseInt(coverage_table2_dep_child2) + parseInt(coverage_table2_dep_child3) + parseInt(coverage_table3_spouse) + parseInt(coverage_table1a_father) + parseInt(coverage_table1a_mother)}</label>
            </div>
            <div class="widthpercent">
              <label className="parent" htmlFor="totalClaim">Maximum Covered in Lakhs 	 :  </label>
              <label className="child">{((parseInt(coverage_table1) + parseInt(coverage_table1a) + parseInt(coverage_table2) + parseInt(coverage_table3) + parseInt(coverage_table1_spouse) +
                parseInt(coverage_table1_dep_child1) + parseInt(coverage_table1_dep_child2) + parseInt(coverage_table1_dep_child3) + parseInt(coverage_table1a_spouse) + parseInt(coverage_table1a_dep_child1) + parseInt(coverage_table1a_dep_child2) + parseInt(coverage_table1a_dep_child3) +
                parseInt(coverage_table2_spouse) + parseInt(coverage_table2_dep_child1) + parseInt(coverage_table2_dep_child2) + parseInt(coverage_table2_dep_child3) + parseInt(coverage_table3_spouse) + parseInt(coverage_table1a_father) + parseInt(coverage_table1a_mother)) / 100000).toFixed(2)}</label>
            </div>
            <div class="widthpercent">
              <label className="parent" htmlFor="totalClaim">Premium to Pay :  </label>
              <label className="child">{(((parseInt(coverage_table1) + parseInt(coverage_table1_spouse) + parseInt(coverage_table1_dep_child1) + parseInt(coverage_table1_dep_child2) + parseInt(coverage_table1_dep_child3)) * parseInt(configTable1_Amount) / 100000) +
                ((parseInt(coverage_table1a_spouse) + parseInt(coverage_table1a_dep_child1) + parseInt(coverage_table1a_dep_child2) + parseInt(coverage_table1a_dep_child3) + parseInt(coverage_table1a) + parseInt(coverage_table1a_father) + parseInt(coverage_table1a_mother)) * parseInt(configTable1a_Amount) / 100000) +
                ((parseInt(coverage_table2) + parseInt(coverage_table2_spouse) + parseInt(coverage_table2_dep_child1) + parseInt(coverage_table2_dep_child2) + parseInt(coverage_table2_dep_child3)) * parseInt(configTable2_Amount) / 100000) +
                ((parseInt(coverage_table3) + parseInt(coverage_table3_spouse)) * parseInt(configTable3_Amount) / 100000)).toFixed(2)
              }</label>
            </div>
          </div>
        </div>
        <div class="form-row">
          <div class="form-col">
            <div class="form-submit">
              <button type="submit" disabled onClick={handleSubmit}>Submit</button>
            </div>
          </div>
          <div class="form-col">
            <div class="form-submit">
              {show && (<button name="printBtn" id="printBtn" type="submit" onClick={printGai}> Print</button>)}
            </div>
          </div>
        </div>
        <div>

        </div>

      </form>
    </div>


  )
}

export default GaiMain;