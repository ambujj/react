import React, { useState } from 'react';
import Popup from '../components/navbar/AlertPopUp';
  
const About = () => {

  const [showPopup, setShowPopup] = useState(false);

  function handleButtonClick() {
    setShowPopup(true);
  }

  return (
    <div>
      <h1>Welcome to MIS </h1>
      {/*<button onClick={handleButtonClick}>Show alert</button>
      {showPopup && <Popup />}*/}
    </div>
  );
};
  
export default About;