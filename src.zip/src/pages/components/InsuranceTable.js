import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

const InsuranceTable = ({ policyConfigData, employmentCategory }) => {
  // Check if policyConfigData is defined and has the data property
  if (!policyConfigData || policyConfigData.length === 0) {
    return null; // Return null or display a placeholder if the data is not available
  }
  //console.log("F Floater"+JSON.stringify(familyFloater))
  const floaterAmt=(familyFloater)=>{
    if(familyFloater>0)
        return familyFloater
    else
        return familyFloater.sumInsured;
  }
 // const selectedDependentsPolicies = useSelector(state => state);
  //console.log("Datass=="+JSON.stringify(selectedDependentsPolicies));

 

  // Filter the policyConfigData based on employmentCategory and familyFloater
  const filteredData = policyConfigData.filter(item => {
   //console.log(item)
    if ((employmentCategory === "Regular" || employmentCategory === "Grade Based Contract") &&
      item.master.memberCategory.id === 9 ) {
      return true;
    } else if (employmentCategory === "Consolidated" &&
      item.master.memberCategory.id === 8 ) {
      return true;
    }
    return false;
  });

  // Check if there are any filtered results
  if (filteredData.length === 0) {
    return <p>Select Floater to view Premium</p>;
  }

  const [highlightedRow, setHighlightedRow] = useState(null);

  useEffect(() => {
    // Code to be executed when the familyFloater prop changes
    // Find the index of the row that matches the familyFloater value
    const index = filteredData.findIndex(item => item.sumInsured === familyFloater);
    setHighlightedRow(index);
  }, []);

  return (
    <table className="insurance-table">
      <thead>
        <tr>
          <th>Sl. No.</th>
          {/*<th>Member Category</th>
          <th>Policy Name</th>*/}
          <th>Sum Insured</th>
          <th>Premium to Pay (Member)</th>
          <th>Premium to Pay (Dependent)</th>
          <th>Premium to Pay (Dependent Parent)</th>
          <th>Premium to Pay (Non-Dependent Parent 1)</th>
          <th>Premium to Pay (Non-Dependent Parent 2)</th>
          <th>Premium to Pay (Non-Dependent Parent In Law 1)</th>
          <th>Premium to Pay (Non-Dependent Parent In Law 2)</th>
        </tr>
      </thead>
      <tbody>
        {filteredData.map((item, index) => (
          <tr
            key={item.id}
            className={highlightedRow === index ? 'highlight-row' : ''}
          >
            <td className='table-th-slno'>{index + 1}</td>
            {/*<td>{item.master.memberCategory.detailCode}</td>
            <td>{item.master.policyName}</td>*/}
            <td>{item.sumInsured}</td>
            <td>{item.premiumToPay}</td>
            <td>{item.premiumToPayDep}</td>
            <td>{item.premiumToPayDepParent}</td>
            <td>{item.premiumToPayNonDep}</td>
            <td>{item.premiumToPayAddon1}</td>
            <td>{item.premiumToPayNonDep}</td>
            <td>{item.premiumToPayAddon1}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default InsuranceTable;
