import React from 'react';

const DependentTable = ({ selectedDependentsPolicies, dependentRows, handleCheckboxToggle, selectAll }) => {
  console.log("Dept Table" + JSON.stringify(dependentRows));

  // Check if a dependent is selected based on the name
  const isDependentSelected = (name) => {
    return selectedDependentsPolicies.some((dependent) => dependent.name === name);
  };

  return (
    <table className="dependent-table">
      <thead>
        <tr>
          <th>Sl No.</th>
          <th>Name</th>
          <th>Date of Birth</th>
          <th>Relation</th>
          <th>Is Dependent?</th>
          <th>Premium for Selected Sum</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {dependentRows.map((row, index) => (
          <tr key={index}>
            <td>{row.slNo}</td>
            <td>{row.name}</td>
            <td>{row.dob}</td>
            <td>{row.relation}</td>
            <td>{row.dependentCategory}</td>
            <td>{row.remarks}</td>
            <td>
              <input
                type="checkbox"
                checked={isDependentSelected(row.name) || selectAll}
                onChange={() => handleCheckboxToggle(index)}
              />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default DependentTable;
