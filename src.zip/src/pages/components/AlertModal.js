import React from "react";

const AlertModal = ({ message }) => {
  return (
    <div
      className="alert alert-info"
      role="alert"
      style={{ maxWidth: "400px" }}
    >
      {message}
      <button
        className="close"
        type="button"
        data-dismiss="alert"
        aria-label="Close"
      >
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  );
};

export default AlertModal;