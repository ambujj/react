
import React from 'react';
  
const Home = (props) => {
  return (
    <div>
      <h1>Welcome to MIS {props.userId}</h1>
    </div>
  );
};
  
export default Home;