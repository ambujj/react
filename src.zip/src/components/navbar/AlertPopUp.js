import React, { useState } from 'react';

const AlertPopup=()=> {
  return (
    <div className="popup">
      <h2>Alert!</h2>
      <p>This is an alert message.</p>
      <button>OK</button>
    </div>
  );
}
export default AlertPopup;

