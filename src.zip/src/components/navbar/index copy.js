import React from 'react';
import {
  Nav,
  NavLink,
  Bars,
  NavMenu,
  NavBtn,
  NavBtnLink,
} from './Navbar';
import { Button} from 'react-bootstrap';
import '../../css/gai.css';
  
const Navbar = () => {
  return (
    <>
      <Nav className="navbar">
        <Bars />
  
        <NavMenu>
          
          <NavBtnLink type="submit" className="menu_button"  to='/gais' activeStyle>
            GAI
          </NavBtnLink>

          <NavBtnLink type="submit" className="menu_button"  to='/mci' activeStyle>
            MCI
          </NavBtnLink>
          <NavBtnLink type="submit" className="menu_button"  to='/mci_config' activeStyle>
            MCI-Config
          </NavBtnLink>
                
          <NavBtnLink type="submit" className="menu_button"  to='/lum' activeStyle>
            Lookup Master
          </NavBtnLink>

          <NavBtnLink type="submit" className="menu_button"  to='/lud' activeStyle>
            Lookup Detail
          </NavBtnLink>

          <h1> Group Personal Accident Insurance Policy </h1>

          </NavMenu>
          
         
          {/* 

          <NavLink to='/reports'  activeStyle>
            Reports
          </NavLink> 

          
          <NavLink to='/about' activeStyle>
            About Gai
          </NavLink>
          <NavBtnLink to='/annual'>Annual</NavBtnLink> 
        
        <NavBtn>
          <NavBtnLink to='/blogs'>Blogs</NavBtnLink>
        </NavBtn>
         */}
        
      </Nav>
    </>
  );
};
  
export default Navbar;