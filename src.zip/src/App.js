import React, { Component, useState, useEffect, useCallback, Radio, ControlLabel, Dropdown } from "react";
import './App.css';
import Navbar from './components/navbar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import GaiMain from './pages/GaiMain';
import Report from './pages/Report';
import Blogs from './pages/Blogs';
import MedClaimInsurance from "./pages/MedClaimInsurance";
import MedClaimInsuranceConfig from "./pages/MedClaimInsuranceConfig";
import LookupMaster from "./pages/LookupMaster";
import LookupDetail from './pages/LookupDetail';
/*
import { useDispatch, useSelector } from 'react-redux';
import { AddUserIdAction } from './actions/UserIdAction';*/
//import { AddTodoAction, RemoveTodoAction } from '../actions/TodoAction';

function App() {

  //const [loading, setLoading] = useState(true);

  //const[userid,setUserid]=useState('');
  //const dispatch = useDispatch();
  //const UserId = useSelector(state=>state.UserId);
  //const {userids}=UserId;


  //const queryParams = new URLSearchParams(window.location.search)
  //const userId = queryParams.get("User_Id") 
  
  const userId = '346543'; //115482  //135640
  //const sessionId = queryParams.get("sessionID") // 115008
  //console.log('UserId'+userId); 
  //console.log('SessionId'+sessionId);


  //const userId='115030'; //135865
  //const sessionId='SEG_GR';
  //setUserid('190229')*/
  console.log('UserId' + userId);
  //console.log('SessionId'+sessionId);

  return (

    <Router>
      <Navbar />
      <Routes>
        <Route path='/' exact element={<MedClaimInsurance userId={userId} />} />        
        <Route path='/medIns' element={<MedClaimInsurance userId={userId} />} />
        <Route path='/gais' element={<GaiMain userId={userId} />} />
        <Route path='/mci_config' element={<MedClaimInsuranceConfig userId={userId} />} />
        <Route path='/lum' element={<LookupMaster userId={userId} />} />
        <Route path='/lud' element={<LookupDetail userId={userId} />} />
        <Route path='/reports' element={<Report userId={userId} />} />
        {/*<Route path='/about' element={<About/>} />
        <Route path='/annual' element={<AnnualReport/>} />
        <Route path='/blogs' element={<Blogs/>} />    */}
      </Routes>
    </Router>

  );
}

export default App;