import { combineReducers } from 'redux';
import mciReducer from './mciReducer'; // import your specific reducer(s)

const rootReducer = combineReducers({
  mciReducer: mciReducer, // add your specific reducer(s) as key-value pairs
  // additional reducers can be added here
});

export default rootReducer;