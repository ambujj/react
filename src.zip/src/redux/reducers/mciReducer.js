import { FETCH_MEDCLAIM_INSURANCE,
  FETCH_MEDCLAIM_INSURANCE_SUCCESS,
  FETCH_MEDCLAIM_INSURANCE_FAILURE
} from '../constants/mciConstant';

// Initial state
const initialState = {
  data: null,
  loading: false,
  error: null,
};

// Reducer function
const mciReducer = (state = initialState, action) => {
  //console.log("action.type"+action.type)
  switch (action.type) {
      case FETCH_MEDCLAIM_INSURANCE:
        return {
          ...state,
          loading: true,
          error: null,
        };
      case FETCH_MEDCLAIM_INSURANCE_SUCCESS:
        return {
          ...state,
          loading: false,
          data: action.payload,
          error: null,
        };
      case FETCH_MEDCLAIM_INSURANCE_FAILURE:
        return {
          ...state,
          loading: false,
          data: null,
          error: action.payload,
        };
    default:
      return state;
  }
};

export default mciReducer;
