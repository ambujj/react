import { applyMiddleware, compose } from 'redux';
import { configureStore } from '@reduxjs/toolkit';
import createSagaMiddleware from 'redux-saga';
import rootReducer from './reducers/index';
import rootSaga from './sagas';

// Create the saga middleware
const sagaMiddleware = createSagaMiddleware();

// Create the Redux store
const store = configureStore({
    reducer: rootReducer, // Wrap rootReducer in an object
    middleware: [sagaMiddleware],
    enhancers: [window.devToolsExtension ? window.devToolsExtension() : (f) => f],
  });

// Run the root saga
sagaMiddleware.run(rootSaga);

export default store;