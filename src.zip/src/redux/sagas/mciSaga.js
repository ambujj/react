import { call, put, takeLatest } from 'redux-saga/effects';
import {
  FETCH_MEDCLAIM_INSURANCE,
  FETCH_MEDCLAIM_INSURANCE_SUCCESS,
  FETCH_MEDCLAIM_INSURANCE_FAILURE
} from '../constants/mciConstant';
import DataService from '../../services/GaiService';

// Worker saga for fetching Med Claim Insurance
function* fetchMedClaimInsuranceSaga(action) {
  try {
    //console.log("I reached Saga");
    const { financialYear, userId } = action.payload;
    const response = yield call(DataService.getMedClaimInsuranceByFinYearEmpCode, financialYear, userId);
    console.log("Response from API:", response.data);
    yield put({ type: FETCH_MEDCLAIM_INSURANCE_SUCCESS, payload: response });
  } catch (error) {
    yield put({ type: FETCH_MEDCLAIM_INSURANCE_FAILURE, payload: error.message });
  }
}


// Watcher saga for fetching Med Claim Insurance
function* mciSaga() {
  yield takeLatest(FETCH_MEDCLAIM_INSURANCE, fetchMedClaimInsuranceSaga);
}

export default mciSaga;
