import { all } from 'redux-saga/effects'
import mciSaga from './mciSaga'

export default function* rootSaga() {
  yield all([
    mciSaga(),
  ])
}