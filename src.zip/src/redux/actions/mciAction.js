import DataService from '../../services/GaiService';

import { FETCH_MEDCLAIM_INSURANCE,
  FETCH_MEDCLAIM_INSURANCE_SUCCESS,
  FETCH_MEDCLAIM_INSURANCE_FAILURE
} from '../constants/mciConstant';

// Action creators
export const fetchMedClaimInsurance = (financialYear, userId) => ({
  type: FETCH_MEDCLAIM_INSURANCE,
  payload: { financialYear, userId },
});

export const fetchMedClaimInsuranceSuccess = (data) => ({
  type: FETCH_MEDCLAIM_INSURANCE_SUCCESS,
  payload: data
});

export const fetchMedClaimInsuranceFailure = (error) => ({
  type: FETCH_MEDCLAIM_INSURANCE_FAILURE,
  payload: {
    error
  }
});

