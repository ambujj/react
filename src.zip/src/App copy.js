import React, { Component , useState, useEffect, useCallback , Radio, ControlLabel, Dropdown} from "react";
import './App.css';
import Navbar from './components/navbar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import GaiMain from './pages/GaiMain';
import AnnualReport from './pages/AnnualReport';
import Blogs from './pages/Blogs';
/*
import { useDispatch, useSelector } from 'react-redux';
import { AddUserIdAction } from './actions/UserIdAction';*/
//import { AddTodoAction, RemoveTodoAction } from '../actions/TodoAction';

function App() {

  const [loading, setLoading] = useState(true);

  //const[userid,setUserid]=useState('');
 // const dispatch = useDispatch();
  //const UserId = useSelector(state=>state.UserId);
  //const {userids}=UserId;

  
   //const queryParams = new URLSearchParams(window.location.search)
   //const userId = queryParams.get("User_Id")
   const userId='115030';
   //const sessionId = queryParams.get("sessionID")
   //console.log('UserId'+userId); 
   //console.log('SessionId'+sessionId);
   
  
   //const userId='115030'; //135865
   //const sessionId='SEG_GR';
   //setUserid('190229')*/
   console.log('UserId'+userId);
   //console.log('SessionId'+sessionId);

  useEffect(() => {
      setLoading(true); // here 
      //fetchInitialData();
      console.log(loading)
  }, []);

  return(!loading ? <div className='App'>          
    <Router basename="/">
      <Navbar />
      <Routes>     
        <Route path='/' exact element={<Home userId={userId}/>} />      
        <Route path='/about' element={<About userId={userId}/>} />
        <Route path='/gai' element={<GaiMain userId={userId}/>} />
      </Routes>
    </Router>          
</div> :<></>);
}
export default App;
